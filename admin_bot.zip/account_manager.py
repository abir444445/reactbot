
import os,asyncio,hashlib,logging
from datetime import datetime,timedelta,timezone
try:
    from zoneinfo import ZoneInfo
except ImportError:
    ZoneInfo=None
from database import MasterDatabase,Database
from monitor import MonitorAccount

class AccountManager:
    def __init__(self,api_pool,notify):
        self.master=MasterDatabase()
        self.api_pool=list(api_pool); self.api_id,self.api_hash=self.api_pool[0]; self.notify=notify
        self.workers={}
        self.dbs={}
        # Resolve the application directory before any migration/path access.
        # This prevents startup crashes when legacy block migration runs.
        self.base_dir=os.path.dirname(os.path.abspath(__file__))
        os.makedirs(os.path.join(self.base_dir, "data", "accounts"), exist_ok=True)
        self._migrate_legacy_blocks()
        self.report_task=None
        self.auto_cycle_task=None
        self._account_lock=asyncio.Lock()
        self._load_accounts()
    def _load_accounts(self):
        for a in self.master.accounts():
            # Normalize legacy relative session paths so a restart from another
            # working directory cannot make an account look missing/offline.
            sf=a.get("session_file") or ""
            if sf and not os.path.isabs(sf):
                sf=os.path.join(self.base_dir,sf)
                self.master.set_session_file(a["id"],sf)
                a["session_file"]=sf
            self._open(a)
    def _open(self,a):
        path=os.path.join(self.base_dir,"data","accounts",f"account_{a['id']}.db")
        db=Database(path); self.dbs[a["id"]]=db
        async def status(aid,status,error=""):
            self.master.set_status(aid,status,error)
        self.workers[a["id"]]=MonitorAccount(a,db,self.api_pool,self.notify,status,self.master.is_user_blocked)
    def _migrate_legacy_blocks(self):
        # Move any older per-account block entries into the single global blocklist.
        for a in self.master.accounts():
            path=os.path.join(self.base_dir,"data","accounts",f"account_{a['id']}.db")
            if not os.path.exists(path):
                continue
            try:
                tmp=Database(path)
                for r in tmp.blocked_users():
                    self.master.block_user(r["user_id"], r.get("username", ""))
                tmp.close()
            except Exception:
                pass

    def is_user_blocked(self, uid): return self.master.is_user_blocked(uid)
    def blocked_users(self): return self.master.blocked_users()
    def block_user(self, uid, username=""): self.master.block_user(uid, username)
    def unblock_user(self, uid): self.master.unblock_user(uid)

    def accounts(self): return self.master.accounts()
    def get(self,aid): return self.master.get(aid)
    def bot_enabled(self): return self.master.get_setting("bot_enabled", "0") == "1"

    def reaction_send_enabled(self):
        return all(db.reaction_send_enabled() for db in self.dbs.values()) if self.dbs else True

    async def set_reaction_send_enabled(self, enabled):
        enabled = bool(enabled)
        for db in self.dbs.values():
            db.set_reaction_send_enabled(enabled)
        if enabled:
            # Re-queue eligible pending reactions without touching scheduled removals.
            for w in self.workers.values():
                if w.running and w.rm.running:
                    for g in w.db.groups():
                        if g["monitoring_enabled"] and g["reaction_enabled"]:
                            w.rm._schedule_threshold(g)
        return enabled

    async def delete_all_reactions(self):
        total = 0
        failed = 0
        for aid, db in self.dbs.items():
            w = self.workers.get(aid)
            if not w or not w.running or not w.client:
                failed += len(db.active_reaction_removals())
                continue
            for r in db.active_reaction_removals():
                try:
                    if await w._remove_reaction(r):
                        db.mark_removed(r["id"])
                        total += 1
                    else:
                        failed += 1
                except Exception:
                    logging.exception("delete all reaction failed")
                    failed += 1
        return total, failed
    def auto_cycle_enabled(self):
        return self.master.get_setting("auto_cycle_enabled", "0") == "1"

    def auto_cycle_minutes(self):
        try:
            return max(1, int(self.master.get_setting("auto_cycle_minutes", "20")))
        except Exception:
            return 20

    async def set_auto_cycle(self, enabled, minutes=None):
        if minutes is not None:
            minutes = max(1, int(minutes))
            self.master.set_setting("auto_cycle_minutes", minutes)
        self.master.set_setting("auto_cycle_enabled", "1" if enabled else "0")
        if self.auto_cycle_task and not self.auto_cycle_task.done():
            self.auto_cycle_task.cancel()
            try:
                await self.auto_cycle_task
            except asyncio.CancelledError:
                pass
        if enabled:
            self.auto_cycle_task = asyncio.create_task(self._auto_cycle_loop())
        return enabled

    async def _auto_cycle_loop(self):
        while self.auto_cycle_enabled():
            await asyncio.sleep(self.auto_cycle_minutes() * 60)
            if not self.auto_cycle_enabled():
                break
            try:
                # Use the exact same manager method as the manual BOT ON/OFF button.
                await self.set_bot_enabled(False)
                await asyncio.sleep(2)
                if self.auto_cycle_enabled():
                    await self.set_bot_enabled(True)
                await self.notify(f"🔄 Auto ON/OFF cycle completed. Next cycle in {self.auto_cycle_minutes()} minutes.")
            except asyncio.CancelledError:
                raise
            except Exception as e:
                logging.exception("auto ON/OFF cycle failed")
                try:
                    await self.notify(f"❌ Auto ON/OFF cycle failed: {e}")
                except Exception:
                    pass

    async def set_bot_enabled(self, enabled):
        enabled = bool(enabled)
        self.master.set_setting("bot_enabled", "1" if enabled else "0")
        for w in list(self.workers.values()):
            if not w.running:
                continue
            if enabled:
                await w.enable_monitoring_fresh()
            else:
                await w.disable_monitoring()
        return enabled
    def worker(self,aid): return self.workers.get(int(aid))
    async def start_all(self):
        enabled = self.bot_enabled()
        for aid,w in list(self.workers.items()):
            if not await w.start():
                self.master.set_status(aid,"offline","Session not authorized")
            elif enabled:
                await w.enable_monitoring_fresh()
            else:
                # A disabled bot must not resume stale reaction work from an
                # earlier process/session. Bot ON will create a fresh baseline.
                self.dbs[aid].clear_pending_all()
    async def stop_all(self):
        if self.auto_cycle_task and not self.auto_cycle_task.done():
            self.auto_cycle_task.cancel()
            try:
                await self.auto_cycle_task
            except asyncio.CancelledError:
                pass
            self.auto_cycle_task=None
        for w in self.workers.values(): await w.stop()
    async def add_account(self,phone):
        phone=phone.strip()
        if not phone:
            raise ValueError("Phone number is required")
        # Serialize account creation so two quick Add Account submissions cannot
        # race and overwrite/login against the same pending record.
        async with self._account_lock:
            existing=self.master.get_by_phone(phone)
            if existing:
                if existing["id"] not in self.workers:
                    self._open(existing)
                return existing
            # Stable session path: Python's built-in hash() changes between
            # processes, which could make a pending account point at a different
            # session file after a restart.
            key=hashlib.sha256(phone.encode("utf-8")).hexdigest()[:24]
            path=os.path.join(self.base_dir,"data","accounts",f"session_{key}.session")
            a=self.master.add_account(phone,path)
            if a["id"] not in self.workers:
                self._open(a)
            return a
    async def remove_account(self,aid):
        aid=int(aid); w=self.workers.pop(aid,None); db=self.dbs.pop(aid,None)
        if w: await w.stop()
        if db: db.close()
        a=self.master.get(aid)
        self.master.remove(aid)
        # Remove only this account's session file; never touch the master DB or
        # another account's files. The per-account SQLite DB is intentionally
        # retained as a safety backup and is ignored until the account is added
        # again, preventing accidental lifetime-data loss.
        if a and a.get("session_file") and os.path.exists(a["session_file"]):
            try: os.remove(a["session_file"])
            except Exception: logging.exception("session cleanup failed")
    def lifetime(self):
        total={"reactions":0,"users":0,"monitored_users":0,"messages":0,"groups":0,"pending":0,"deletes":0}
        for db in self.dbs.values():
            s=db.stats()
            total["reactions"]+=s["lifetime_reactions"]
            total["users"]+=s["lifetime_users"]
            total["monitored_users"]+=s["lifetime_monitored_users"]
            total["messages"]+=s["lifetime_messages"]
            total["groups"]+=s["groups"]
            total["pending"]+=s["pending"]; total["deletes"]+=s["pending_deletes"]
        total["accounts"]=len(self.dbs)
        return total
    def _bd_now(self):
        tz=ZoneInfo("Asia/Dhaka") if ZoneInfo else timezone(timedelta(hours=6))
        return datetime.now(tz)

    def daily_reaction_report(self, target_date):
        lines=[f"📋 Daily Reaction Report — {target_date.strftime('%Y-%m-%d')} (Bangladesh time)", ""]; total=0
        for aid,db in self.dbs.items():
            a=self.master.get(aid); breakdown=db.daily_reaction_breakdown(target_date)
            if not breakdown: continue
            lines.append(f"📱 Account: {a['phone']}")
            for r in breakdown:
                g=db.get_group(r['group_id']); title=(g.get('group_title') if g else '') or '(unknown group)'; uname=(f"@{g['group_username']}" if g and g.get('group_username') else 'private/no username')
                lines.append(f"  • {title} ({uname}) — {r['reactions']} reactions"); total += int(r['reactions'])
            lines.append("")
        lines.append(f"Total reactions: {total}" if total else "No reactions were sent today.")
        return "\n".join(lines)

    async def start_daily_reporter(self):
        if self.report_task and not self.report_task.done(): return
        current=self._bd_now().date().isoformat(); last=self.master.get_setting("last_daily_report_date","")
        if not last: self.master.set_setting("last_daily_report_date",current)
        elif last < current:
            try: await self.notify(self.daily_reaction_report(datetime.strptime(last,"%Y-%m-%d").date()))
            except Exception: logging.exception("missed daily report failed")
            self.master.set_setting("last_daily_report_date",current)
        async def loop():
            while True:
                try:
                    today=self._bd_now().date(); last=self.master.get_setting("last_daily_report_date","")
                    if last and today.isoformat()!=last:
                        await self.notify(self.daily_reaction_report(datetime.strptime(last,"%Y-%m-%d").date()))
                        self.master.set_setting("last_daily_report_date",today.isoformat())
                except asyncio.CancelledError: raise
                except Exception: logging.exception("daily report loop failed")
                await asyncio.sleep(5)
        self.report_task=asyncio.create_task(loop(),name="bangladesh-daily-report")

    async def stop_daily_reporter(self):
        if self.report_task:
            self.report_task.cancel()
            try: await self.report_task
            except asyncio.CancelledError: pass
            self.report_task=None
        self.auto_cycle_task=None
        self._account_lock=asyncio.Lock()
        self.base_dir=os.path.dirname(os.path.abspath(__file__))

    def daily_group_status(self, day=None):
        tz = ZoneInfo("Asia/Dhaka") if ZoneInfo else timezone(timedelta(hours=6))
        target = datetime.now(tz).date() if day is None else (day if hasattr(day, "year") else datetime.strptime(str(day), "%Y-%m-%d").date())
        out=[]
        for a in self.master.accounts():
            aid=a["id"]; db=self.dbs.get(aid)
            if not db: continue
            for r in db.daily_group_status(target):
                out.append({"account_id":aid,"phone":a["phone"], **r})
        return {"day":target.strftime("%Y-%m-%d"),"groups":out}

    async def reset_daily(self):
        """Reset today's dashboard window and restart monitoring from a fresh baseline."""
        was_enabled = self.bot_enabled()
        if was_enabled:
            await self.set_bot_enabled(False)
        reset_at = datetime.utcnow().isoformat(sep=" ", timespec="seconds")
        for db in self.dbs.values():
            db.reset_daily_stats(reset_at)
        # Clear any in-memory reaction work as well; existing scheduled removals
        # are intentionally retained so reactions already sent can still be removed.
        if was_enabled:
            await self.set_bot_enabled(True)
        else:
            for w in self.workers.values():
                if w.running:
                    w.db.clear_pending_all()
        return True

    def daily(self):
        # Keep the presentation contract stable for AdminBot: the dashboard
        # expects the Bangladesh-local calendar day as well as the counters.
        target = self._bd_now().date()
        ds=[db.daily(target) for db in self.dbs.values()]
        return {
            "day": target.strftime("%Y-%m-%d"),
            "reactions":sum(x.get("reactions",0) for x in ds),
            "messages":sum(x.get("messages",0) for x in ds),
            "users":sum(x.get("reacted_users",0) for x in ds),
            "monitored_users":sum(x.get("monitored_users",0) for x in ds),
            "deletes":sum(x.get("deletes",0) for x in ds),
            "active_accounts":sum(1 for w in self.workers.values() if w.running and w.bot_enabled),
        }
