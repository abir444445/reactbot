import asyncio, logging, os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, CommandHandler, CallbackQueryHandler, MessageHandler, filters
from telegram.error import BadRequest, TimedOut, NetworkError
from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError

logger=logging.getLogger(__name__)


class AdminBot:
    def __init__(self,manager,app):
        self.m=manager
        self.app=app
        self.awaiting={}   # chat_id -> pending setting/add action
        self.login={}      # chat_id -> login state

    def register(self):
        self.app.add_handler(CommandHandler("start",self.start))
        self.app.add_handler(CallbackQueryHandler(self.callback))
        self.app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,self.text))

    def admin(self,chat):
        return int(chat)==int(os.getenv("ADMIN_CHAT_ID","0") or 0)

    def menu(self):
        state="🟢 BOT ON" if self.m.bot_enabled() else "🔴 BOT OFF"
        reaction_state="🟢 REACTION SEND ON" if self.m.reaction_send_enabled() else "🔴 REACTION SEND OFF"
        return InlineKeyboardMarkup([
            [InlineKeyboardButton(state,callback_data="bot:toggle")],
            [InlineKeyboardButton(reaction_state,callback_data="reaction_send:toggle"),InlineKeyboardButton("🗑 Delete All Reactions",callback_data="delete_all_reactions")],
            [InlineKeyboardButton("📊 Dashboard",callback_data="dash"),InlineKeyboardButton("📈 Daily Status",callback_data="daily")],
            [InlineKeyboardButton("👤 Accounts",callback_data="accounts")],
            [InlineKeyboardButton("🚫 Global Blocklist",callback_data="blocks")],
            [InlineKeyboardButton("⚙️ Reaction Settings",callback_data="settings")],
            [InlineKeyboardButton("🔁 Auto ON/OFF Timer",callback_data="autocycle")],
        ])

    async def start(self,u,c):
        if not self.admin(u.effective_chat.id): return
        text="🤖 ZEO Market Reaction System\n\nMultiple Account / isolated database mode."
        for attempt in range(3):
            try:
                await u.message.reply_text(text,reply_markup=self.menu())
                return
            except (TimedOut, NetworkError):
                if attempt == 2: raise
                await asyncio.sleep(2 * (attempt + 1))

    async def edit(self,q,text,kb=None):
        for attempt in range(3):
            try:
                await q.edit_message_text(text,reply_markup=kb)
                return
            except BadRequest as e:
                if "Message is not modified" in str(e): return
                raise
            except (TimedOut, NetworkError):
                if attempt == 2: raise
                await asyncio.sleep(2 * (attempt + 1))

    def accounts_kb(self):
        rows=[]
        for a in self.m.accounts():
            w=self.m.worker(a["id"])
            st="🟢" if w and w.running else ("🚫" if a["status"]=="banned" else "🔴")
            rows.append([InlineKeyboardButton(f"{st} {a['phone']}",callback_data=f"acc:{a['id']}")])
        rows.append([InlineKeyboardButton("➕ Add Account",callback_data="add_account")])
        rows.append([InlineKeyboardButton("🔙 Main Menu",callback_data="main")])
        return InlineKeyboardMarkup(rows)

    async def show_accounts(self,q):
        txt="👤 Accounts\n\nSelect an account. Every account has its own DB, groups, settings and worker." if self.m.accounts() else "👤 Accounts\n\nNo accounts added."
        await self.edit(q,txt,self.accounts_kb())

    async def show_account(self,q,aid):
        a=self.m.get(aid); w=self.m.worker(aid); db=self.m.dbs[int(aid)]
        st="🟢 Running" if w and w.running else ("🚫 Banned" if a["status"]=="banned" else "🔴 Offline")
        txt=(f"👤 Account: {a['phone']}\nStatus: {st}\n\n"
             f"Groups: {len(db.groups())}\nPending reactions: {db.pending_count_all()}\nPending deletes: {db.pending_delete_count()}")
        kb=InlineKeyboardMarkup([
            [InlineKeyboardButton("👥 Group List / Add Group",callback_data=f"groups:{aid}"),InlineKeyboardButton("⚙️ Settings",callback_data=f"aset:{aid}")],
            [InlineKeyboardButton("🔄 Start/Restart",callback_data=f"startacc:{aid}"),InlineKeyboardButton("⏹ Stop",callback_data=f"stopacc:{aid}")],
            [InlineKeyboardButton("🗑 Remove Account",callback_data=f"rmacc:{aid}")],
            [InlineKeyboardButton("🔙 Accounts",callback_data="accounts")]])
        await self.edit(q,txt,kb)

    async def show_groups(self,q,aid):
        db=self.m.dbs[int(aid)]; gs=db.groups()
        txt=f"👥 Groups\nAccount: {self.m.get(aid)['phone']}\n\n"
        kb=[]
        for g in gs:
            react="❤️" if g["reaction_enabled"] else "🚫"
            label=g["group_title"] or "Unnamed Group"
            uname=(f" @{g['group_username']}" if g["group_username"] else f" [{g['group_id']}]")
            kb.append([InlineKeyboardButton(f"{react} {label}{uname}"[:60],callback_data=f"grp:{aid}:{g['group_id']}")])
        kb += [[InlineKeyboardButton("➕ Add Group",callback_data=f"addgrp:{aid}")],
               [InlineKeyboardButton("🔙 Account",callback_data=f"acc:{aid}")]]
        await self.edit(q,txt,InlineKeyboardMarkup(kb))

    async def show_joined_groups(self,q,aid):
        w=self.m.worker(aid)
        if not w or not w.running:
            await self.edit(q,"❌ Account is offline. Start the account first.",InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Account",callback_data=f"acc:{aid}")]]))
            return
        joined=await w.get_joined_groups()
        configured={g["group_id"] for g in self.m.dbs[int(aid)].groups()}
        rows=[]
        for g in joined:
            mark="✅" if g["group_id"] in configured else "➕"
            uname=f" @{g['group_username']}" if g["group_username"] else f" [{g['group_id']}]"
            title=g["group_title"] or "Unnamed Group"
            rows.append([InlineKeyboardButton(f"{mark} {title}{uname}"[:60],callback_data=f"pickgrp:{aid}:{g['group_id']}")])
        if not rows:
            text="➕ Add Group\n\nNo joined groups were found for this account. Private groups without a username are also supported when the account is already a member."
        else:
            text=("➕ Add Group\n\nSelect one of this account's joined groups.\n"
                  "Private groups without a username are included.\n\n"
                  "The selected group starts monitoring immediately when Bot is ON.")
        rows.append([InlineKeyboardButton("🔄 Refresh Joined Groups",callback_data=f"addgrp:{aid}")])
        rows.append([InlineKeyboardButton("🔙 Group List",callback_data=f"groups:{aid}")])
        await self.edit(q,text,InlineKeyboardMarkup(rows))

    async def show_group(self,q,aid,gid):
        db=self.m.dbs[int(aid)]; g=db.get_group(gid)
        if not g: return await self.show_groups(q,aid)
        label=g["group_title"] or "Unnamed Group"
        username_line=f"@{g['group_username']}" if g["group_username"] else "No username (private/hidden)"
        txt=(f"👥 {label}\nUsername: {username_line}\nAccount: {self.m.get(aid)['phone']}\n\n"
             f"Reaction: {'🟢 ON' if g['reaction_enabled'] else '🚫 OFF'}\n"
             f"Status: {'🚫 Banned' if g['banned'] else '✅ OK'}")
        kb=InlineKeyboardMarkup([
            [InlineKeyboardButton("❤️ Reaction ON/OFF",callback_data=f"react:{aid}:{gid}")],
            [InlineKeyboardButton("🔄 Sync Group",callback_data=f"sync:{aid}:{gid}")],
            [InlineKeyboardButton("🗑 Remove Group",callback_data=f"rmgrp:{aid}:{gid}")],
            [InlineKeyboardButton("🔙 Group List",callback_data=f"groups:{aid}")]])
        await self.edit(q,txt,kb)

    async def _send_blocks_message(self, u):
        rows=self.m.blocked_users()
        text="🚫 Global Blocklist\n\n"
        text += f"Blocked users: {len(rows)}\n\n"
        text += "\n".join(f"• {r['user_id']}" + (f" (@{r['username']})" if r.get('username') else "") for r in rows) if rows else "No blocked users."
        text += "\n\n🌐 GLOBAL RULE: a blocked user cannot receive a reaction from ANY account in ANY configured group. Their pending reaction jobs are removed immediately."
        kb=[[InlineKeyboardButton("➕ Add Block",callback_data="blockadd")]]
        for r in rows: kb.append([InlineKeyboardButton(f"❌ Remove {r['user_id']}",callback_data=f"blockrm:{r['user_id']}")])
        kb.append([InlineKeyboardButton("🔙 Main Menu",callback_data="main")])
        await u.message.reply_text(text, reply_markup=InlineKeyboardMarkup(kb))

    async def show_blocks(self,q):
        rows=self.m.blocked_users()
        text="🚫 Global Blocklist\n\n"
        text += f"Blocked users: {len(rows)}\n\n"
        text += "\n".join(f"• {r['user_id']}" + (f" (@{r['username']})" if r.get('username') else "") for r in rows) if rows else "No blocked users."
        text += "\n\n🌐 GLOBAL RULE: a blocked user cannot receive a reaction from ANY account in ANY configured group. Their pending reaction jobs are removed immediately."
        kb=[[InlineKeyboardButton("➕ Add Block",callback_data="blockadd")]]
        for r in rows: kb.append([InlineKeyboardButton(f"❌ Remove {r['user_id']}",callback_data=f"blockrm:{r['user_id']}")])
        kb.append([InlineKeyboardButton("🔙 Main Menu",callback_data="main")])
        await self.edit(q,text,InlineKeyboardMarkup(kb))

    async def show_settings(self,q,aid=None):
        if aid is None:
            rows=[]
            for a in self.m.accounts():
                groups=self.m.dbs[int(a["id"])].groups()
                rows.append([InlineKeyboardButton(f"📱 {a['phone']}  •  {len(groups)} groups",callback_data=f"aset:{a['id']}")])
            rows.append([InlineKeyboardButton("🔙 Main Menu",callback_data="main")])
            return await self.edit(q,"⚙️ Reaction Settings\n\nFirst select an account, then select the group.\nEach group has its own independent reaction settings.",InlineKeyboardMarkup(rows))
        aid=int(aid); db=self.m.dbs[aid]; groups=db.groups()
        rows=[]
        for g in groups:
            gs=db.group_settings(g["group_id"]); mark="🟢" if g["reaction_enabled"] else "🔴"
            label=g.get("group_title") or g.get("group_username") or g["group_id"]
            rows.append([InlineKeyboardButton(f"{mark} {label}"[:60],callback_data=f"gset:{aid}:{g['group_id']}")])
        rows.append([InlineKeyboardButton("🔙 Accounts",callback_data="settings")])
        return await self.edit(q,f"⚙️ Reaction Settings\nAccount: {self.m.get(aid)['phone']}\n\nSelect a group:",InlineKeyboardMarkup(rows))

    async def show_group_settings(self,q,aid,gid):
        db=self.m.dbs[int(aid)]; g=db.get_group(gid)
        if not g:
            return await self.show_settings(q,aid)
        s=db.group_settings(gid); pool=" ".join(s["reaction_emojis"])
        label=g.get("group_title") or g.get("group_username") or gid
        txt=(f"⚙️ Group Reaction Settings\n\n👥 Group: {label}\n"
             f"📊 Queue Threshold: {s['queue_threshold']} messages\n"
             f"⏱ Reaction Interval: {s['reaction_interval_seconds']:g} seconds\n"
             f"🗑 Delete Time: {s['reaction_remove_after_hours']:g} hours\n"
             f"❤️ Reaction Pool: {pool}\n"
             f"👤 User Reaction Limit: {s['user_reaction_limit']} per user/day (0 = unlimited)\n\n"
             f"Newest {s['queue_threshold']} messages in this group are protected from reaction.")
        kb=InlineKeyboardMarkup([
            [InlineKeyboardButton("📊 Queue",callback_data=f"gth:{aid}:{gid}"),InlineKeyboardButton("⏱ Interval",callback_data=f"gint:{aid}:{gid}")],
            [InlineKeyboardButton("🗑 Delete Time",callback_data=f"gdel:{aid}:{gid}"),InlineKeyboardButton("❤️ Reactions",callback_data=f"greact:{aid}:{gid}")],
            [InlineKeyboardButton("👤 User Limit",callback_data=f"gulimit:{aid}:{gid}")],
            [InlineKeyboardButton("🔙 Group Settings",callback_data=f"aset:{aid}"),InlineKeyboardButton("🏠 Main",callback_data="main")]])
        await self.edit(q,txt,kb)

    async def show_auto_cycle(self,q):
        enabled=self.m.auto_cycle_enabled()
        minutes=self.m.auto_cycle_minutes()
        status="🟢 ENABLED" if enabled else "🔴 DISABLED"
        text=(f"🔁 Auto ON/OFF Timer\n\nStatus: {status}\n"
              f"Timer: every {minutes} minute(s)\n\n"
              "The bot will automatically perform the same OFF → ON action as the main BOT button. "
              "No monitoring/reaction logic is changed.")
        kb=InlineKeyboardMarkup([
            [InlineKeyboardButton("⏱ Set Timer",callback_data="setautotimer")],
            [InlineKeyboardButton("🟢 Enable" if not enabled else "🔴 Disable",callback_data="toggleautocycle")],
            [InlineKeyboardButton("🔙 Main Menu",callback_data="main")]])
        await self.edit(q,text,kb)

    async def callback(self,u,c):
        q=u.callback_query
        if not self.admin(q.message.chat_id): return
        await q.answer()
        p=q.data.split(":"); h=p[0]
        try:
            if h=="main": await self.edit(q,"🤖 ZEO Market Reaction System",self.menu())
            elif h=="bot":
                enabled=not self.m.bot_enabled(); await self.m.set_bot_enabled(enabled)
                state="🟢 ON" if enabled else "🔴 OFF"
                msg=f"🤖 Bot is now {state}.\n\nWhen turned ON, monitoring starts from the current moment. Older messages are ignored and are never backfilled."
                await self.edit(q,msg,self.menu())
            elif h=="reaction_send":
                enabled=not self.m.reaction_send_enabled()
                await self.m.set_reaction_send_enabled(enabled)
                state="🟢 ON" if enabled else "🔴 OFF"
                msg=(f"❤️ Reaction sending is now {state}.\n\n"
                     "When OFF, no new reactions will be sent. Already-sent reactions keep their original removal time and will still be removed on schedule.")
                await self.edit(q,msg,self.menu())
            elif h=="delete_all_reactions":
                sent, failed = await self.m.delete_all_reactions()
                if failed:
                    msg=f"🗑 Delete All Reactions\n\nRemoved: {sent}\nFailed/unavailable: {failed}\n\nThe failed items remain scheduled for normal removal."
                else:
                    msg=f"🗑 Delete All Reactions\n\nRemoved: {sent}\n\nAll currently tracked reactions were removed."
                await self.edit(q,msg,self.menu())
            elif h=="accounts": await self.show_accounts(q)
            elif h=="acc": await self.show_account(q,int(p[1]))
            elif h=="groups": await self.show_groups(q,int(p[1]))
            elif h=="addgrp": await self.show_joined_groups(q,int(p[1]))
            elif h=="pickgrp":
                aid=int(p[1]); gid=":".join(p[2:])
                w=self.m.worker(aid)
                actual=await w.add_joined_group(gid) if w else False
                await self.show_groups(q,aid)
            elif h=="grp": await self.show_group(q,int(p[1]),":".join(p[2:]))
            elif h=="sync":
                aid=int(p[1]); gid=":".join(p[2:]); w=self.m.worker(aid)
                if w and w.running:
                    await w.add_joined_group(gid)
                await self.show_group(q,aid,gid)
            elif h=="react":
                aid=int(p[1]); gid=":".join(p[2:]); db=self.m.dbs[aid]; g=db.get_group(gid)
                db.update_group(gid,reaction_enabled=0 if g["reaction_enabled"] else 1)
                await self.show_group(q,aid,gid)
            elif h=="add_account":
                self.awaiting[q.message.chat_id]="phone"
                await self.edit(q,"➕ Add Account\n\nSend the account phone number, e.g. +8801XXXXXXXXX",InlineKeyboardMarkup([[InlineKeyboardButton("Cancel",callback_data="accounts")]]))
            elif h=="rmgrp":
                aid=int(p[1]); gid=":".join(p[2:]); self.m.dbs[aid].remove_group(gid); await self.show_groups(q,aid)
            elif h=="rmacc":
                await self.m.remove_account(int(p[1])); await self.show_accounts(q)
            elif h=="startacc":
                aid=int(p[1]); w=self.m.worker(aid); ok=await w.start()
                if ok and self.m.bot_enabled(): await w.enable_monitoring_fresh()
                self.m.master.set_status(aid,"active" if ok else "offline"); await self.show_account(q,aid)
            elif h=="stopacc":
                aid=int(p[1]); await self.m.worker(aid).stop(); self.m.master.set_status(aid,"offline"); await self.show_account(q,aid)
            elif h=="aset": await self.show_settings(q,int(p[1]))
            elif h=="gset": await self.show_group_settings(q,int(p[1]),":".join(p[2:]))
            elif h=="blocks": await self.show_blocks(q)
            elif h=="blockadd":
                self.awaiting[q.message.chat_id]="globalblock"
                await self.edit(q,"🚫 Global Block User\n\nSend Telegram user ID or @username.\n\nThis block is GLOBAL: the user will never receive a reaction from ANY account in ANY group until you remove them from the blocklist.",InlineKeyboardMarkup([[InlineKeyboardButton("Back",callback_data="blocks")]]))
            elif h=="blockrm":
                self.m.unblock_user(int(p[1])); await self.show_blocks(q)
            elif h=="settings": await self.show_settings(q)
            elif h=="autocycle": await self.show_auto_cycle(q)
            elif h=="setautotimer":
                self.awaiting[q.message.chat_id]="autotimer"
                await self.edit(q,
                    "⏱ Auto ON/OFF Timer\n\nSend the timer in minutes. Example: 20\nMinimum: 1 minute.",
                    InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back",callback_data="autocycle")]]))
            elif h=="toggleautocycle":
                enabled=not self.m.auto_cycle_enabled()
                await self.m.set_auto_cycle(enabled)
                await self.show_auto_cycle(q)
            elif h in {"gth","gint","gdel","greact","gulimit"}:
                aid=int(p[1]); gid=":".join(p[2:]); back=f"gset:{aid}:{gid}"
                kind={"gth":"threshold","gint":"interval","gdel":"delete","greact":"reactions","gulimit":"userlimit"}[h]
                self.awaiting[q.message.chat_id]=f"{kind}:{aid}:{gid}"
                prompts={
                    "threshold":"📊 Queue Threshold\n\nSend the number of newer messages required before a message can receive a reaction. Example: 40",
                    "interval":"⏱ Reaction Interval\n\nSend seconds between reactions in THIS group. Minimum: 5 seconds.",
                    "delete":"🗑 Delete Time\n\nSend how many hours a reaction stays before removal. Example: 72",
                    "reactions":"❤️ Reaction Pool\n\nSend emojis separated by commas. Example: ❤️,👍,😂,🔥",
                    "userlimit":"👤 User Reaction Limit\n\nSend maximum successful reactions per user per Bangladesh day. Send 0 for unlimited."}
                await self.edit(q,prompts[kind],InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back",callback_data=back)]]))
            elif h=="dash": await self.dashboard(q)
            elif h=="daily": await self.daily(q)
            elif h=="daily_reset_confirm": await self.daily_reset_confirm(q)
            elif h=="daily_reset": await self.daily_reset(q)
            elif h=="daily_groups": await self.daily_groups(q)
        except Exception as e:
            logger.exception("callback error")
            await q.message.reply_text(f"❌ Error: {e}")

    async def text(self,u,c):
        if not self.admin(u.effective_chat.id): return
        chat=u.effective_chat.id; raw=(u.message.text or "").strip(); action=self.awaiting.pop(chat,None)
        if action=="autotimer":
            try:
                val=int(raw)
                if val < 1: raise ValueError("minimum is 1 minute")
                await self.m.set_auto_cycle(True, val)
                await u.message.reply_text(f"✅ Auto ON/OFF enabled. It will click OFF → ON every {val} minute(s).", reply_markup=self.menu())
            except Exception as e:
                await u.message.reply_text(f"❌ Invalid timer: {e}", reply_markup=self.menu())
            return
        if action=="phone":
            a=await self.m.add_account(raw); self.login[chat]={"aid":a["id"],"phone":raw,"step":"code"}
            client=TelegramClient(a["session_file"],self.m.api_id,self.m.api_hash,flood_sleep_threshold=0); await client.connect()
            try:
                sent=await client.send_code_request(raw)
                self.login[chat].update(client=client,hash=sent.phone_code_hash)
                await u.message.reply_text("📩 Telegram code sent. Send the login code here.")
            except Exception:
                await client.disconnect(); self.login.pop(chat,None); raise
            return
        if chat in self.login:
            st=self.login[chat]
            if st["step"]=="code":
                try:
                    await st["client"].sign_in(st["phone"],raw,phone_code_hash=st["hash"])
                    await st["client"].disconnect(); self.login.pop(chat,None)
                    aid=st["aid"]; self.m.master.set_status(aid,"active"); w=self.m.worker(aid); await w.start()
                    if self.m.bot_enabled(): await w.enable_monitoring_fresh()
                    await u.message.reply_text("✅ Account added and started.",reply_markup=self.menu())
                except SessionPasswordNeededError:
                    st["step"]="password"; await u.message.reply_text("🔐 Two-Step Verification enabled. Send the Telegram password.")
                except Exception as e: await u.message.reply_text(f"❌ Login failed: {e}")
                return
            if st["step"]=="password":
                try:
                    await st["client"].sign_in(password=raw); await st["client"].disconnect(); self.login.pop(chat,None)
                    aid=st["aid"]; self.m.master.set_status(aid,"active"); w=self.m.worker(aid); await w.start()
                    if self.m.bot_enabled(): await w.enable_monitoring_fresh()
                    await u.message.reply_text("✅ Account added and started.",reply_markup=self.menu())
                except Exception as e: await u.message.reply_text(f"❌ Login failed: {e}")
                return
        if not action: return
        if action=="globalblock":
            kind="globalblock"; aid=None; gid=None; db=None
        else:
            parts=action.split(":"); kind=parts[0]; aid=int(parts[1]); gid=":".join(parts[2:]) if len(parts)>2 else None; db=self.m.dbs[aid]
        try:
            if kind=="globalblock":
                resolved=None
                if raw.lstrip("-").isdigit():
                    resolved={"user_id":int(raw),"username":""}
                else:
                    for w in self.m.workers.values():
                        if w and w.running:
                            try:
                                resolved=await w.resolve_user(raw)
                                if resolved: break
                            except Exception:
                                continue
                if not resolved: raise ValueError("user not found; use a valid Telegram user ID or @username")
                self.m.block_user(resolved["user_id"],resolved.get("username", ""))
                # Remove that user's pending work from every account immediately.
                for adb in self.m.dbs.values():
                    adb.conn.execute("DELETE FROM pending_queue WHERE user_id=?",(int(resolved["user_id"]),)); adb.conn.commit()
                await u.message.reply_text(f"🚫 User {resolved['user_id']} is now globally blocked.\n\nNo reaction will be sent to this user by ANY account/group until unblocked. Any pending reaction jobs for this user were removed.", reply_markup=self.menu())
                # Keep the admin in the blocklist workflow so multiple users can be blocked quickly.
                await self._send_blocks_message(u); return
            if kind in {"threshold","interval","delete","reactions","userlimit"}:
                if not gid: raise ValueError("group is missing")
                if kind=="threshold":
                    val=int(raw)
                    if val<=0: raise ValueError("threshold must be > 0")
                    db.set_group_setting(gid,"queue_threshold",val)
                elif kind=="interval":
                    val=float(raw)
                    if val<5: raise ValueError("minimum interval is 5 seconds")
                    db.set_group_setting(gid,"reaction_interval_seconds",int(val) if val.is_integer() else val)
                elif kind=="delete":
                    val=float(raw)
                    if val<=0: raise ValueError("delete time must be > 0")
                    db.set_group_setting(gid,"reaction_remove_after_hours",int(val) if val.is_integer() else val)
                    updated = db.reschedule_active_removals(gid, val)
                elif kind=="reactions":
                    vals=[x.strip() for x in raw.replace(";",",").replace("\n",",").split(",") if x.strip()]
                    if not vals: raise ValueError("add at least one reaction")
                    if len(vals)>20: raise ValueError("maximum 20 reactions")
                    if any(len(x)>16 for x in vals): raise ValueError("invalid reaction emoji")
                    db.set_group_setting(gid,"reaction_emojis",__import__("json").dumps(vals,ensure_ascii=False))
                elif kind=="userlimit":
                    val=int(raw)
                    if val<0: raise ValueError("limit must be 0 or greater")
                    db.set_group_setting(gid,"user_reaction_limit",val)
                await u.message.reply_text("✅ Group setting updated.",reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⚙️ Back to Group Settings",callback_data=f"gset:{aid}:{gid}")],[InlineKeyboardButton("🔙 Account Groups",callback_data=f"aset:{aid}"),InlineKeyboardButton("🏠 Main",callback_data="main")]]))
        except Exception as e:
            await u.message.reply_text(f"❌ Invalid value: {e}")

    async def dashboard(self,q):
        d=self.m.lifetime(); pending=sum(db.pending_count_all() for db in self.m.dbs.values()); deletes=sum(db.pending_delete_count() for db in self.m.dbs.values())
        await self.edit(q,(f"📊 Dashboard — Lifetime\n\n💬 Messages monitored: {d['messages']}\n👥 Users monitored: {d['monitored_users']}\n❤️ Lifetime reactions: {d['reactions']}\n👤 Users reacted to: {d['users']}\n📱 Total accounts: {d['accounts']}\n👥 Total groups: {d['groups']}\n⏳ Pending reactions: {pending}\n🗑 Pending deletes: {deletes}"),InlineKeyboardMarkup([[InlineKeyboardButton("🔄 Refresh",callback_data="dash"),InlineKeyboardButton("📈 Daily Status",callback_data="daily")],[InlineKeyboardButton("🔙 Main",callback_data="main")]]))

    async def daily_groups(self,q):
        d=self.m.daily_group_status()
        rows=d.get("groups",[])
        txt=f"📊 Daily Group Status — {d.get('day','')} (Bangladesh time)\n\n"
        if not rows:
            txt += "No groups configured."
        else:
            current=None
            number=0
            for r in rows:
                if r["account_id"] != current:
                    current=r["account_id"]; number+=1
                    txt += f"{number}️⃣ {r['phone']}\n"
                name=(r.get("group_username") or "").strip()
                if not name:
                    name=(r.get("group_title") or "").strip()
                if not name:
                    name=r["group_id"]
                if name and not name.startswith("@"): name="("+name+")"
                else: name="("+name+")"
                txt += f"{name} — Total Message: {r['messages']} | Total Reaction Sent: {r['reactions']} | Pending: {r['pending']}\n"
            
        await self.edit(q,txt,InlineKeyboardMarkup([[InlineKeyboardButton("🔄 Refresh",callback_data="daily_groups")],[InlineKeyboardButton("📈 Daily Status",callback_data="daily"),InlineKeyboardButton("🔙 Main",callback_data="main")]]))

    async def daily(self,q):
        d=self.m.daily()
        txt=(f"📈 Daily Status — {d.get('day','')} (Bangladesh time)\n\n"
             f"💬 Messages monitored: {d.get('messages',0)}\n👥 Total users: {d.get('monitored_users',0)}\n"
             f"❤️ Reactions given: {d.get('reactions',0)}\n👤 Users reacted to: {d.get('users',0)}\n"
             f"🗑 Reactions deleted: {d.get('deletes',0)}\n"
             f"📱 Active accounts: {d.get('active_accounts',0)}\n\n"
             f"Daily data is kept separately from lifetime statistics.")
        await self.edit(q,txt,InlineKeyboardMarkup([[InlineKeyboardButton("🔄 Refresh",callback_data="daily"),InlineKeyboardButton("📊 Group Status",callback_data="daily_groups")],[InlineKeyboardButton("♻️ Reset Today",callback_data="daily_reset_confirm")],[InlineKeyboardButton("🔙 Main",callback_data="main")]]))

    async def daily_reset_confirm(self,q):
        await self.edit(q,"⚠️ Reset today's status?\n\nThis will clear today's dashboard counters and pending reaction queue, then start monitoring again from a fresh baseline. Lifetime statistics and scheduled reaction deletes will remain safe.",InlineKeyboardMarkup([[InlineKeyboardButton("✅ Yes, Reset Today",callback_data="daily_reset")],[InlineKeyboardButton("🔙 Cancel",callback_data="daily")]]))

    async def daily_reset(self,q):
        await self.m.reset_daily()
        await self.daily(q)
