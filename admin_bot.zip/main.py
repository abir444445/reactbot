import asyncio,logging,os
from telegram.ext import Application
from telegram.request import HTTPXRequest
from telegram.error import TimedOut, NetworkError
from config import ADMIN_BOT_TOKEN,ADMIN_CHAT_ID,API_POOL
from account_manager import AccountManager
from admin_bot import AdminBot
logging.basicConfig(level=getattr(logging, os.getenv("LOG_LEVEL","INFO").upper(), logging.INFO),format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
async def main():
    if not ADMIN_BOT_TOKEN or not ADMIN_CHAT_ID or not API_POOL:
        raise SystemExit("Set ADMIN_BOT_TOKEN, ADMIN_CHAT_ID and at least API_ID_1/API_HASH_1 in .env")
    request = HTTPXRequest(
        connection_pool_size=32,
        connect_timeout=60.0,
        read_timeout=60.0,
        write_timeout=60.0,
        pool_timeout=60.0,
        media_write_timeout=60.0,
    )
    app=Application.builder().token(ADMIN_BOT_TOKEN).request(request).get_updates_request(HTTPXRequest(
        connection_pool_size=16,
        connect_timeout=60.0,
        read_timeout=60.0,
        write_timeout=60.0,
        pool_timeout=60.0,
    )).build()
    async def notify(text):
        try: await app.bot.send_message(chat_id=int(ADMIN_CHAT_ID),text=text,parse_mode="Markdown")
        except Exception: logging.exception("admin notification failed")
    manager=AccountManager(API_POOL,notify)
    bot=AdminBot(manager,app)
    bot.register()
    async def error_handler(update, context):
        err = context.error
        if isinstance(err, (TimedOut, NetworkError)):
            logging.warning("Telegram network timeout; polling/handler will continue: %s", err)
        else:
            logging.exception("Unhandled admin bot error", exc_info=err)
    app.add_error_handler(error_handler)
    await app.initialize(); await app.start(); await app.updater.start_polling()
    await manager.start_all()
    await manager.start_daily_reporter()
    try:
        await asyncio.Event().wait()
    finally:
        await manager.stop_daily_reporter(); await manager.stop_all(); await app.updater.stop(); await app.stop(); await app.shutdown()
if __name__=="__main__": asyncio.run(main())
