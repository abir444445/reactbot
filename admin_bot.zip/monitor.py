import asyncio
import logging
import random
from typing import Optional, Callable, Awaitable

from telethon import TelegramClient, events, errors, functions, types, utils as tl_utils

from reaction_manager import ReactionManager

logger = logging.getLogger(__name__)

GROUP_ERRORS = (
    errors.ChatWriteForbiddenError,
    errors.UserBannedInChannelError,
    errors.ChannelPrivateError,
    errors.UserNotParticipantError,
    errors.ChatAdminRequiredError,
)
SESSION_ERRORS = (
    errors.AuthKeyUnregisteredError,
    errors.SessionRevokedError,
    errors.UserDeactivatedBanError,
    errors.UserDeactivatedError,
)


class MonitorAccount:
    """One isolated Telegram account worker.

    Incoming Telegram events are deliberately kept lightweight: the event handler
    only puts the message into an asyncio queue. A dedicated consumer persists the
    message and hands it to ReactionManager. A small history reconciler also runs
    periodically, so short disconnects / event-loop stalls cannot permanently lose
    messages from the counters.
    """

    def __init__(self, account, db, api_pool,
                 notify: Optional[Callable[[str], Awaitable[None]]] = None,
                 status: Optional[Callable] = None,
                 global_block_checker: Optional[Callable[[int], bool]] = None):
        self.account = account
        self.db = db
        self.api_pool = list(api_pool)
        # Accounts start on DIFFERENT API slots so 4-5 accounts never
        # hammer the same API at once (prevents FloodWait storms).
        self.api_index = int(account.get("id", 0)) % len(self.api_pool)
        self.api_id, self.api_hash = self.api_pool[self.api_index]
        self.notify = notify or (lambda text: asyncio.sleep(0))
        self.status_callback = status
        self.global_block_checker = global_block_checker or (lambda uid: False)
        self.client = None
        self.running = False
        self.paused = False
        self.bot_enabled = False
        self.message_queue: asyncio.Queue = asyncio.Queue(maxsize=10000)
        self.tasks = []
        self.watchdog_task = None
        self.group_sync_lock = asyncio.Lock()
        self._last_recovery_notice = 0.0
        self._api_switch_lock = asyncio.Lock()
        # Sender protection cache: Telegram bots and group admins/owners are
        # always counted as messages but are never added to the reaction queue.
        # The cache avoids a permission API call for every message.
        self._protected_sender_cache = {}
        self._protected_sender_cache_ttl = 600
        # Group-level admin ID cache. This is a second, stronger protection
        # path for cases where get_permissions() does not expose the
        # participant role reliably for a particular Telegram group.
        self._group_admin_cache = {}
        self._group_admin_cache_ttl = 60
        self.rm = ReactionManager(db, self._send_reaction, self.global_block_checker)
        self.rm.remove_callback = self._remove_reaction

    async def start(self):
        if self.client and self.client.is_connected() and self.running:
            return True
        try:
            self.client = TelegramClient(
                self.account["session_file"], self.api_id, self.api_hash,
                flood_sleep_threshold=0
            )
            await self.client.connect()
            if not await self.client.is_user_authorized():
                await self._close()
                return False

            me = await self.client.get_me()
            self.account["phone"] = self.account.get("phone") or (getattr(me, "phone", "") or "")
            self.running = True
            self.paused = False
            self.bot_enabled = False
            self.db.set("account_phone", self.account["phone"])

            self._register_event_handler()
            await self.sync_groups()
            # Monitoring is intentionally OFF after worker startup. The admin
            # must press the global Bot ON button; that creates a fresh baseline
            # so historical messages are never counted/reaction-queued.
            # Separate tasks keep message ingestion, recovery and group work from
            # blocking each other during fast bursts (e.g. several messages/sec).
            self.tasks = [
                asyncio.create_task(self._message_consumer(), name=f"msg-consumer-{self.account['id']}"),
                asyncio.create_task(self._history_loop(), name=f"history-sync-{self.account['id']}"),
            ]
            self.watchdog_task = asyncio.create_task(self._watchdog_loop(), name=f"monitor-watchdog-{self.account['id']}")
            self.tasks.append(self.watchdog_task)
            return True
        except SESSION_ERRORS as e:
            await self._close()
            await self.notify_session_ban(str(e))
            return False
        except Exception as e:
            logger.exception("account start failed")
            await self._close()
            await self.notify(f"⚠️ Account start error\nAccount: {self.account.get('phone','')}\n{e}")
            return False

    def _register_event_handler(self):
        client = self.client
        @client.on(events.NewMessage())
        async def handler(event):
            await self._enqueue_event(event)

    async def _switch_api(self):
        """Switch to the next working API pair. Tries every configured slot and
        keeps the old client alive if no new slot connects, so the account is
        never left with a dead connection (which silently broke removals)."""
        if len(self.api_pool) <= 1:
            return False
        async with self._api_switch_lock:
            start_index = self.api_index
            for step in range(1, len(self.api_pool) + 1):
                idx = (start_index + step) % len(self.api_pool)
                api_id, api_hash = self.api_pool[idx]
                client = TelegramClient(
                    self.account["session_file"], api_id, api_hash,
                    flood_sleep_threshold=0
                )
                try:
                    await client.connect()
                    if not await client.is_user_authorized():
                        await client.disconnect()
                        continue
                    old = self.client
                    self.client = client
                    self.api_index = idx
                    self.api_id, self.api_hash = api_id, api_hash
                    self._register_event_handler()
                    if old:
                        try:
                            await old.disconnect()
                        except Exception:
                            pass
                    logger.warning("API switched to slot %s for account %s", idx + 1, self.account.get("phone"))
                    return True
                except Exception:
                    try:
                        await client.disconnect()
                    except Exception:
                        pass
            logger.error("no working API slot found for account %s", self.account.get("phone"))
            return False

    async def _reaction_request(self, request_factory):
        """Run a reaction request; on FloodWait, try the next API pair.
        Re-raises the REAL last FloodWaitError so set_floodwait() always
        receives a valid .seconds value (the old capture= code could crash
        inside the except block and permanently stall reaction removal)."""
        attempts = max(1, len(self.api_pool))
        last_exc = None
        for _ in range(attempts):
            try:
                return await self.client(request_factory())
            except errors.FloodWaitError as e:
                last_exc = e
                if len(self.api_pool) <= 1:
                    raise
                if not await self._switch_api():
                    raise
        if last_exc is not None:
            raise last_exc
        raise RuntimeError("reaction request failed on every configured API")

    async def _close(self):
        self.running = False
        for task in self.tasks:
            if not task.done():
                task.cancel()
        for task in self.tasks:
            try:
                await task
            except asyncio.CancelledError:
                pass
            except Exception:
                logger.exception("worker task shutdown failed")
        self.tasks = []
        self.watchdog_task = None
        try:
            await self.rm.stop()
        except Exception:
            logger.exception("reaction manager shutdown failed")
        if self.client:
            try:
                await self.client.disconnect()
            except Exception:
                pass
        self.client = None

    async def stop(self):
        await self._close()


    async def _watchdog_loop(self):
        """Self-heal the account runtime without changing monitoring baselines."""
        while self.running:
            try:
                # Telethon normally reconnects itself, but an explicit health check
                # prevents a permanently disconnected client from silently leaving
                # the monitor alive while no new events arrive.
                if self.client and not self.client.is_connected():
                    await self.client.connect()
                    if not await self.client.is_user_authorized():
                        await self.notify_session_ban("Telegram session is no longer authorized")
                        return
                    logger.warning("reconnected Telegram client for account %s", self.account.get("phone"))
                    await self.sync_groups()

                live = {t.get_name(): t for t in self.tasks if not t.done()}
                consumer_name = f"msg-consumer-{self.account['id']}"
                history_name = f"history-sync-{self.account['id']}"
                if self.bot_enabled and consumer_name not in live:
                    t = asyncio.create_task(self._message_consumer(), name=consumer_name)
                    self.tasks.append(t)
                    logger.warning("restarted dead message consumer for account %s", self.account.get("phone"))
                if self.running and history_name not in live:
                    t = asyncio.create_task(self._history_loop(), name=history_name)
                    self.tasks.append(t)
                    logger.warning("restarted dead history sync for account %s", self.account.get("phone"))

                if self.bot_enabled and not self.rm.running:
                    await self.rm.start()
                    logger.warning("restarted reaction manager for account %s", self.account.get("phone"))
            except asyncio.CancelledError:
                raise
            except Exception as e:
                logger.exception("monitor watchdog failed")
                now = __import__("time").monotonic()
                if now >= self._last_recovery_notice:
                    self._last_recovery_notice = now + 120
                    try:
                        await self.notify(f"⚠️ Runtime recovery warning\nAccount: {self.account.get('phone','')}\nThe monitor detected a runtime problem and will keep retrying automatically.\nError: {e}")
                    except Exception:
                        pass
            await asyncio.sleep(15)

    async def _enqueue_event(self, event):
        if not self.running or self.paused or not self.bot_enabled:
            return
        try:
            # Never perform DB writes / API calls in the Telethon event callback.
            # This is important when a group receives many messages in a second.
            self.message_queue.put_nowait(event)
        except asyncio.QueueFull:
            # Do not block the Telegram event loop. History reconciliation will
            # recover messages if an exceptional burst fills the queue.
            logger.warning("message queue full for account %s; history sync will recover missed messages", self.account.get("phone"))

    async def _message_consumer(self):
        while self.running:
            event = await self.message_queue.get()
            try:
                await self.process(event)
            except Exception:
                logger.exception("message consumer failed")
            finally:
                self.message_queue.task_done()

    async def _group_admin_ids(self, chat):
        """Return current admin/owner user IDs for a group, with short caching."""
        import time
        gid = str(getattr(chat, "id", chat))
        now_m = time.monotonic()
        cached = self._group_admin_cache.get(gid)
        if cached and cached[1] > now_m:
            return cached[0]

        admin_ids = set()
        try:
            # This explicitly asks Telegram for the group's admin list instead
            # of relying only on a per-user permission lookup.
            admins = await self.client.get_participants(
                chat, filter=types.ChannelParticipantsAdmins()
            )
            for participant in admins or []:
                pid = getattr(participant, "id", None)
                if pid is not None:
                    admin_ids.add(int(pid))
        except Exception as e:
            logger.debug("admin list lookup failed for %s: %s", gid, e)

        self._group_admin_cache[gid] = (admin_ids, now_m + self._group_admin_cache_ttl)
        return admin_ids

    async def _is_protected_sender(self, chat, uid, sender=None):
        """Return True for Telegram bots or group admins/owners.

        Protected messages are still persisted/count toward message statistics;
        this flag only prevents them from entering the reaction queue. Admin
        detection uses both direct permissions and a cached Telegram admin list.
        The same check is also performed immediately before sending a reaction,
        so an admin can never receive an automatic reaction even if the message
        was queued before the account learned that user was an admin.
        """
        if uid is None:
            return False

        if sender is not None and getattr(sender, "bot", False):
            return True

        # Anonymous admin posts can be represented by the group/channel itself.
        if sender is not None and isinstance(sender, (types.Chat, types.Channel)):
            return True

        import time
        key = (str(getattr(chat, "id", chat)), int(uid))
        cached = self._protected_sender_cache.get(key)
        now_m = time.monotonic()
        if cached and cached[1] > now_m:
            return cached[0]

        protected = False

        # Primary check: direct Telegram permissions.
        try:
            perms = await self.client.get_permissions(chat, int(uid))
            protected = bool(
                getattr(perms, "is_admin", False)
                or getattr(perms, "is_creator", False)
            )
        except (errors.UserNotParticipantError, errors.ChannelPrivateError, errors.ChatAdminRequiredError):
            protected = False
        except Exception:
            protected = False

        # Strong fallback: compare against Telegram's current admin list.
        if not protected:
            try:
                protected = int(uid) in await self._group_admin_ids(chat)
            except Exception:
                protected = False

        self._protected_sender_cache[key] = (protected, now_m + self._protected_sender_cache_ttl)
        return protected

    async def process(self, event):
        if not self.running or self.paused or not self.bot_enabled:
            return
        try:
            chat = await event.get_chat()
            if not self._is_group(chat):
                return
            gid = str(event.chat_id)
            g = self.db.get_group(gid)
            if not g or not g["monitoring_enabled"] or not g["valid_group"]:
                return

            uid = event.sender_id
            if uid is None:
                return
            sender = event.sender
            username = getattr(sender, "username", "") or ""
            message = event.message
            created = self._message_date(message)
            baseline = int(g.get("monitor_baseline_msg_id") or 0)
            started_at = g.get("monitor_started_at") or ""
            if int(message.id) <= baseline or (started_at and created and created < started_at):
                return
            inserted = self.db.add_message(
                uid, username, gid, message.id, message.text or "", created_at=created
            )
            if inserted and not self.db.is_user_blocked(uid):
                # Admin/owner and bot/security-bot messages count normally but
                # are permanently excluded from automatic reactions.
                if await self._is_protected_sender(chat, uid, sender):
                    logger.debug("protected sender skipped for reaction: group=%s uid=%s", gid, uid)
                    return
                await self.rm.new_message(gid, event.chat_id, message.id, uid, username, created_at=created)
        except Exception as e:
            logger.exception("message process: %s", e)

    @staticmethod
    def _message_date(message):
        dt = getattr(message, "date", None)
        if not dt:
            return None
        return dt.replace(tzinfo=None).isoformat(sep=" ", timespec="seconds")

    async def _send_reaction(self, row, g):
        uid = int(row["user_id"])
        if self.global_block_checker(uid):
            return False

        # Final safety gate immediately before the Telegram reaction request.
        # This catches admin messages that were already in the queue before the
        # admin cache was refreshed or before the user was promoted to admin.
        try:
            entity = await self.client.get_entity(int(row["chat_id"]))
            if await self._is_protected_sender(entity, uid):
                logger.info(
                    "admin/bot sender skipped at reaction time: group=%s uid=%s msg=%s",
                    g["group_id"], uid, row["msg_id"]
                )
                return True
        except Exception as e:
            # If Telegram cannot resolve the group, do not guess that a sender
            # is an admin; the normal reaction request will handle the error.
            logger.debug("final sender protection check failed: %s", e)

        # Pick one reaction randomly from the admin-configured pool.
        emoji = random.choice(self.db.group_reaction_emojis(g["group_id"]))
        try:
            await self._reaction_request(lambda: functions.messages.SendReactionRequest(
                peer=row["chat_id"],
                msg_id=row["msg_id"],
                reaction=[types.ReactionEmoji(emoticon=emoji)],
                add_to_recent=True,
            ))
            self.db.log_reaction(g["group_id"], row["user_id"], row["msg_id"], emoji, True)
            self.db.add_removal(g["group_id"], row["chat_id"], row["msg_id"], row["user_id"], emoji)
            return True
        except errors.MessageIdInvalidError:
            self.db.log_reaction(g["group_id"], row["user_id"], row["msg_id"], emoji, False, "Message deleted")
            return True
        except errors.FloodWaitError as e:
            # Do not hammer Telegram while FloodWait is active. Message ingestion
            # continues; pending reactions stay queued and are retried after the
            # exact server-mandated cooldown.
            self.rm.set_floodwait(e.seconds)
            now_m = __import__("time").monotonic()
            if now_m >= getattr(self.rm, "_flood_notice_at", 0.0):
                self.rm._flood_notice_at = now_m + max(30, int(e.seconds))
                await self.notify(
                    f"⚠️ Telegram rate limit\nAccount: {self.account['phone']}\n"
                    f"Group: {g.get('group_username') or g.get('group_title')}\nWait: {e.seconds}s\n\n"
                    f"Messages are still being monitored; pending reactions will resume automatically."
                )
        except GROUP_ERRORS as e:
            self.db.update_group(g["group_id"], banned=1, monitoring_enabled=0)
            await self.notify(
                f"⚠️ **Account Group Banned**\n\nAccount: `{self.account['phone']}`\n"
                f"Group: `{g.get('group_username') or ''}`\nGroup Name: {g.get('group_title') or ''}\nStatus: Banned"
            )
        except SESSION_ERRORS as e:
            await self.notify_session_ban(str(e))
        except Exception as e:
            self.db.log_reaction(g["group_id"], row["user_id"], row["msg_id"], emoji, False, str(e))
        return False

    async def _remove_reaction(self, r):
        try:
            await self._reaction_request(lambda: functions.messages.SendReactionRequest(
                peer=int(r["chat_id"]), msg_id=int(r["msg_id"]), reaction=[]
            ))
            logger.info("reaction removed: group=%s msg=%s", r["group_id"], r["msg_id"])
            return True
        except errors.MessageIdInvalidError:
            # Message already deleted — nothing left to remove.
            return True
        except (errors.ChatWriteForbiddenError, errors.ChannelPrivateError,
                errors.UserNotParticipantError, errors.ChatAdminRequiredError):
            # We lost access to the group — clean up the row.
            return True
        except errors.FloodWaitError as e:
            self.rm.set_floodwait(e.seconds)
            return False
        except Exception as e:
            logger.warning("remove reaction failed (msg=%s): %s", r["msg_id"], e)
            return False

    @staticmethod
    def _is_group(e):
        return isinstance(e, types.Chat) or (
            isinstance(e, types.Channel)
            and bool(getattr(e, "megagroup", False))
            and not getattr(e, "broadcast", False)
        )

    async def sync_groups(self):
        async with self.group_sync_lock:
            for g in list(self.db.groups()):
                try:
                    await self.refresh_group_metadata(g["group_id"])
                except Exception:
                    logger.exception("group metadata sync failed for %s", g["group_id"])

    async def get_joined_groups(self):
        """Return groups this account is already a member of, including private groups.

        This uses the account's dialogs rather than a username/link, so private
        groups without any public username can be selected as well.
        """
        if not self.client:
            return []
        found=[]
        async for dialog in self.client.iter_dialogs():
            entity=getattr(dialog, "entity", None)
            if not entity or not self._is_group(entity):
                continue
            gid=str(tl_utils.get_peer_id(entity))
            found.append({
                "group_id":gid,
                "group_title":getattr(entity, "title", "") or "",
                "group_username":getattr(entity, "username", "") or "",
            })
        return found

    async def resolve_user(self, identifier):
        """Resolve a Telegram user id or @username for block management."""
        if not self.client: return None
        ident=str(identifier).strip()
        try:
            entity=await self.client.get_entity(int(ident) if ident.lstrip("-").isdigit() else ident.lstrip("@"))
            uid=getattr(entity,"id",None)
            if uid is None: return None
            return {"user_id":int(uid),"username":getattr(entity,"username","") or ""}
        except Exception:
            return None

    async def add_joined_group(self, gid):
        """Add an already-joined group without trying to join it again."""
        if not self.client:
            return False
        try:
            entity=await self.client.get_entity(int(gid) if str(gid).lstrip("-").isdigit() else gid)
            if not self._is_group(entity):
                return False
            actual=str(tl_utils.get_peer_id(entity))
            title=getattr(entity, "title", "") or actual
            username=getattr(entity, "username", "") or ""
            self.db.add_group(actual, username, title)
            self.db.update_group(actual, monitoring_enabled=1, reaction_enabled=1, banned=0, valid_group=1,
                                 group_username=username, group_title=title)
            if self.bot_enabled:
                await self.prepare_group_fresh(actual)
            return actual
        except Exception as e:
            logger.warning("add joined group failed for %s: %s", gid, e)
            return False

    async def prepare_group_fresh(self, gid):
        """Reset a single group's monitoring cursor to now; never backfill."""
        if not self.client or not self.running:
            return False
        try:
            entity = await self.client.get_entity(int(gid) if str(gid).lstrip("-").isdigit() else gid)
            latest = await self.client.get_messages(entity, limit=1)
            latest_id = int(latest[0].id) if latest else 0
            stamp = __import__("datetime").datetime.utcnow().isoformat(sep=" ", timespec="seconds")
            self.db.clear_group_queue(str(gid))
            self.db.set_monitor_baseline(str(gid), stamp, latest_id)
            self.db.set_group_last_reaction_at(str(gid), 0)
            return True
        except Exception as e:
            logger.warning("fresh group baseline failed for %s: %s", gid, e)
            return False

    async def enable_monitoring_fresh(self):
        """Turn monitoring on from *now*. Existing messages are baseline only.

        We intentionally do not backfill. For each configured group we capture the
        current latest message id, clear stale pending work, then accept only
        messages arriving after this point.
        """
        if not self.running or not self.client:
            return False
        self.bot_enabled = False
        await self.rm.stop()
        self.db.clear_pending_all()
        # Drain events queued before the ON transition.
        while not self.message_queue.empty():
            try:
                self.message_queue.get_nowait(); self.message_queue.task_done()
            except asyncio.QueueEmpty:
                break
        stamp = __import__("datetime").datetime.utcnow().isoformat(sep=" ", timespec="seconds")
        # This timestamp defines the beginning of the current monitoring session.
        # Daily dashboard numbers are calculated from this point, preventing
        # activity from an earlier ON session from leaking into TODAY.
        self.db.set("monitor_session_started_at", stamp)
        for g in list(self.db.groups()):
            if not g["monitoring_enabled"] or not g["valid_group"]:
                continue
            try:
                entity = await self.client.get_entity(int(g["group_id"]))
                latest = await self.client.get_messages(entity, limit=1)
                latest_id = int(latest[0].id) if latest else 0
                self.db.set_monitor_baseline(g["group_id"], stamp, latest_id)
                self.db.set_group_last_reaction_at(g["group_id"], 0)
            except Exception as e:
                logger.warning("baseline setup failed for %s: %s", g["group_id"], e)
                self.db.set_monitor_baseline(g["group_id"], stamp, 0)
                self.db.set_group_last_reaction_at(g["group_id"], 0)
        self.bot_enabled = True
        await self.rm.start()
        logger.info("fresh monitoring enabled for account %s", self.account.get("phone"))
        return True

    async def disable_monitoring(self):
        self.bot_enabled = False
        self.db.clear_pending_all()
        while not self.message_queue.empty():
            try:
                self.message_queue.get_nowait(); self.message_queue.task_done()
            except asyncio.QueueEmpty:
                break
        await self.rm.stop()
        return True

    async def _history_loop(self):
        # Reconcile recent history periodically. This catches messages missed by
        # reconnects, queue saturation, temporary Telegram update gaps, or a newly
        # added group. It is intentionally bounded to avoid locking the worker.
        while self.running:
            try:
                await asyncio.sleep(10)
                if not self.running or not self.client or not self.bot_enabled:
                    continue
                for g in list(self.db.groups()):
                    if not g["monitoring_enabled"] or not g["valid_group"]:
                        continue
                    try:
                        await self.refresh_group_metadata(g["group_id"])
                        await self.backfill_group(g["group_id"], limit=500, min_id=int(g.get("monitor_baseline_msg_id") or 0))
                    except Exception:
                        logger.exception("periodic history sync failed for %s", g["group_id"])
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("history loop failed")

    async def refresh_group_metadata(self, gid):
        """Refresh title/username without attempting to join the group again."""
        if not self.client:
            return
        try:
            entity = await self.client.get_entity(int(gid) if str(gid).lstrip("-").isdigit() else gid)
            if self._is_group(entity):
                title = getattr(entity, "title", "") or ""
                username = getattr(entity, "username", "") or ""
                self.db.update_group(str(gid), group_title=title, group_username=username, valid_group=1)
        except Exception as e:
            logger.debug("metadata refresh failed for %s: %s", gid, e)

    async def backfill_group(self, gid, limit=2000, min_id=0):
        g = self.db.get_group(gid)
        if not g or not g["monitoring_enabled"] or not g["valid_group"]:
            return
        try:
            entity = await self.client.get_entity(int(gid))
            recovered = 0
            # Telegram returns newest first by default. reverse=True lets us
            # insert missing messages chronologically, which keeps queue ordering.
            async for msg in self.client.iter_messages(entity, limit=limit, min_id=int(min_id or 0), reverse=True):
                if not msg or not msg.id or not getattr(msg, "sender_id", None):
                    continue
                if getattr(msg, "action", None) is not None:
                    continue
                sender = msg.sender
                if sender is None:
                    try:
                        sender = await msg.get_sender()
                    except Exception:
                        sender = None
                username = getattr(sender, "username", "") if sender else ""
                created = self._message_date(msg)
                baseline = int(g.get("monitor_baseline_msg_id") or 0)
                started_at = g.get("monitor_started_at") or ""
                if int(msg.id) <= baseline or (started_at and created and created < started_at):
                    continue
                if self.db.add_message(
                    msg.sender_id, username, gid, msg.id, msg.text or "", created_at=created
                ):
                    if await self._is_protected_sender(entity, msg.sender_id, sender):
                        logger.debug("protected history sender skipped for reaction: group=%s uid=%s", gid, msg.sender_id)
                        recovered += 1
                        continue
                    await self.rm.new_message(
                        gid, msg.chat_id, msg.id, msg.sender_id, username, created_at=created
                    )
                    recovered += 1
            if recovered:
                logger.info(
                    "Recovered %s messages for group %s (%s)",
                    recovered, gid, g.get("group_title") or g.get("group_username") or gid,
                )
        except (errors.FloodWaitError, errors.ChannelPrivateError) as e:
            logger.warning("history sync temporarily unavailable for %s: %s", gid, e)
        except Exception as e:
            logger.warning("history sync failed for group %s: %s", gid, e)

    async def add_group(self, identifier):
        try:
            ent = await self.join(identifier)
            if ent is None:
                return False
            if not self._is_group(ent):
                self.db.update_group(identifier, valid_group=0, monitoring_enabled=0)
                return False
            gid = str(tl_utils.get_peer_id(ent))
            title = getattr(ent, "title", "") or gid
            username = getattr(ent, "username", "") or ""
            old = self.db.get_group(identifier)
            if gid != str(identifier):
                if old:
                    self.db.add_group(gid, username, title)
                    self.db.update_group(
                        gid,
                        monitoring_enabled=old["monitoring_enabled"],
                        reaction_enabled=old["reaction_enabled"],
                        banned=0,
                        valid_group=1,
                        group_username=username,
                        group_title=title,
                    )
                    self.db.remove_group(identifier)
                else:
                    self.db.add_group(gid, username, title)
            else:
                self.db.update_group(
                    gid,
                    group_username=username,
                    group_title=title,
                    banned=0,
                    valid_group=1,
                )
            if self.bot_enabled:
                try:
                    latest = await self.client.get_messages(ent, limit=1)
                    latest_id = int(latest[0].id) if latest else 0
                    stamp = __import__("datetime").datetime.utcnow().isoformat(sep=" ", timespec="seconds")
                    self.db.set_monitor_baseline(gid, stamp, latest_id)
                except Exception:
                    pass
            return gid
        except Exception as e:
            logger.warning("add group failed: %s", e)
            return False

    async def join(self, ident):
        if not self.client:
            return None
        ident = str(ident).strip()
        if "joinchat" in ident or "+" in ident:
            h = ident.split("/")[-1].lstrip("+")
            u = await self.client(functions.messages.ImportChatInviteRequest(h))
            return u.chats[0] if getattr(u, "chats", None) else None
        ent = await self.client.get_entity(int(ident) if ident.lstrip("-").isdigit() else ident)
        if not self._is_group(ent):
            return None
        if isinstance(ent, types.Channel):
            try:
                await self.client(functions.channels.JoinChannelRequest(ent))
            except errors.UserAlreadyParticipantError:
                pass
        return ent

    async def remove_group(self, gid):
        self.db.clear_group_queue(gid)
        self.db.update_group(gid, monitoring_enabled=0)

    async def notify_session_ban(self, reason=""):
        self.account["status"] = "banned"
        if self.status_callback:
            try:
                await self.status_callback(self.account["id"], "banned", reason)
            except Exception:
                pass
        groups = [g for g in self.db.groups() if g.get("reaction_enabled")]
        text = (
            f"🚫 **Account Banned**\n\nAccount: `{self.account['phone']}`\n"
            f"Reason: {reason}\n\nThis account reacted in:\n"
        )
        if groups:
            text += "\n".join(
                f"{i}. `{g.get('group_username') or '(no username)'}` — {g.get('group_title') or '(no name)'}"
                for i, g in enumerate(groups, 1)
            )
        else:
            text += "No configured groups."
        await self.notify(text)
        await self._close()
