import os
from dotenv import load_dotenv
load_dotenv()

ADMIN_BOT_TOKEN = os.getenv("ADMIN_BOT_TOKEN", "")
ADMIN_CHAT_ID = os.getenv("ADMIN_CHAT_ID", "")

def _api_pool():
    out = []
    # API_ID_1 .. API_ID_5 — 4-5 ta API support
    for i in range(1, 6):
        raw_id = os.getenv(f"API_ID_{i}", "").strip()
        raw_hash = os.getenv(f"API_HASH_{i}", "").strip()
        if raw_id and raw_hash:
            try:
                out.append((int(raw_id), raw_hash))
            except ValueError:
                pass
    # Backward compatibility with the old single API_ID/API_HASH format.
    if not out:
        raw_id = os.getenv("API_ID", "").strip()
        raw_hash = os.getenv("API_HASH", "").strip()
        if raw_id and raw_hash:
            try:
                out.append((int(raw_id), raw_hash))
            except ValueError:
                pass
    return out

API_POOL = _api_pool()
API_ID, API_HASH = API_POOL[0] if API_POOL else (0, "")

LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FILE = os.getenv("LOG_FILE", "bot.log")