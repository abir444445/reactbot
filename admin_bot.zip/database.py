
import os, sqlite3, json

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
from datetime import datetime, timedelta, timezone
try:
    from zoneinfo import ZoneInfo
except ImportError:
    ZoneInfo = None

def now(): return datetime.utcnow().isoformat(sep=" ", timespec="seconds")
def today():
    tz = ZoneInfo("Asia/Dhaka") if ZoneInfo else timezone(timedelta(hours=6))
    return datetime.now(tz).strftime("%Y-%m-%d")

class Database:
    """Per-account database. No plan/burst/waiting state exists here."""
    def __init__(self, path):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        self.path=path
        self.conn=sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory=sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA foreign_keys=ON")
        self._schema()

    def _schema(self):
        c=self.conn.cursor()
        c.execute("CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT)")
        defaults={
            "queue_threshold":"40",
            "reaction_interval_seconds":"5",
            "reaction_remove_after_hours":"72",
            "reaction_send_enabled":"1",
            "reaction_emojis":"❤️",
            "monitor_paused":"0",
            "user_reaction_limit":"0",
            "user_reaction_period_hours":"48",
            "monitor_session_started_at":"",
            "daily_reset_at":"",
        }
        for k,v in defaults.items(): c.execute("INSERT OR IGNORE INTO settings VALUES(?,?)",(k,v))
        # Migrate the previous single-emoji setting into the new reaction pool
        # when an older database does not already have a pool.
        old_emoji=c.execute("SELECT value FROM settings WHERE key='reaction_emoji'").fetchone()
        pool_row=c.execute("SELECT value FROM settings WHERE key='reaction_emojis'").fetchone()
        if old_emoji and pool_row and pool_row[0] == "❤️":
            c.execute("UPDATE settings SET value=? WHERE key='reaction_emojis'", (json.dumps([old_emoji[0]], ensure_ascii=False),))
        c.execute("""CREATE TABLE IF NOT EXISTS groups(
            group_id TEXT PRIMARY KEY, group_username TEXT DEFAULT '', group_title TEXT DEFAULT '',
            monitoring_enabled INTEGER DEFAULT 1, reaction_enabled INTEGER DEFAULT 1,
            banned INTEGER DEFAULT 0, valid_group INTEGER DEFAULT 1, added_date TEXT,
            monitor_started_at TEXT DEFAULT '', monitor_baseline_msg_id INTEGER DEFAULT 0,
            last_reaction_at REAL DEFAULT 0,
            queue_threshold INTEGER DEFAULT 40, reaction_interval_seconds REAL DEFAULT 5,
            reaction_remove_after_hours REAL DEFAULT 72, reaction_emojis TEXT DEFAULT '["❤️"]',
            user_reaction_limit INTEGER DEFAULT 0)""")
        c.execute("""CREATE TABLE IF NOT EXISTS messages(
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, username TEXT DEFAULT '',
            group_id TEXT, message_id INTEGER, content TEXT DEFAULT '', created_at TEXT,
            UNIQUE(group_id, message_id))""")
        c.execute("""CREATE TABLE IF NOT EXISTS pending_queue(
            id INTEGER PRIMARY KEY AUTOINCREMENT, group_id TEXT, chat_id INTEGER, msg_id INTEGER,
            user_id INTEGER, username TEXT DEFAULT '', created_at TEXT,
            UNIQUE(group_id,chat_id,msg_id))""")
        c.execute("""CREATE TABLE IF NOT EXISTS reactions_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT, group_id TEXT, user_id INTEGER,
            message_id INTEGER, emoji TEXT, success INTEGER DEFAULT 1, error TEXT,
            created_at TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS reaction_removals(
            id INTEGER PRIMARY KEY AUTOINCREMENT, group_id TEXT, chat_id INTEGER, msg_id INTEGER,
            user_id INTEGER, emoji TEXT, remove_after TEXT, removed INTEGER DEFAULT 0,
            removed_at TEXT, created_at TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS account_activity(
            day TEXT PRIMARY KEY, active INTEGER DEFAULT 0, messages INTEGER DEFAULT 0,
            reactions INTEGER DEFAULT 0, reacted_users INTEGER DEFAULT 0)""")
        # Migrate reaction removal timestamps for daily delete statistics.
        try:
            c.execute("ALTER TABLE reaction_removals ADD COLUMN created_at TEXT")
        except sqlite3.OperationalError:
            pass
        # Older installations may have been created before the UNIQUE constraint
        # existed. Remove duplicate rows once, then enforce uniqueness at DB level.
        c.execute("""DELETE FROM messages
                     WHERE id NOT IN (SELECT MIN(id) FROM messages GROUP BY group_id, message_id)""")
        # Schema migration for existing group tables.
        cols={r[1] for r in c.execute("PRAGMA table_info(groups)").fetchall()}
        if "monitor_started_at" not in cols:
            c.execute("ALTER TABLE groups ADD COLUMN monitor_started_at TEXT DEFAULT ''")
        if "monitor_baseline_msg_id" not in cols:
            c.execute("ALTER TABLE groups ADD COLUMN monitor_baseline_msg_id INTEGER DEFAULT 0")
        if "last_reaction_at" not in cols:
            c.execute("ALTER TABLE groups ADD COLUMN last_reaction_at REAL DEFAULT 0")
        if "queue_threshold" not in cols:
            c.execute("ALTER TABLE groups ADD COLUMN queue_threshold INTEGER DEFAULT 40")
        if "reaction_interval_seconds" not in cols:
            c.execute("ALTER TABLE groups ADD COLUMN reaction_interval_seconds REAL DEFAULT 5")
        if "reaction_remove_after_hours" not in cols:
            c.execute("ALTER TABLE groups ADD COLUMN reaction_remove_after_hours REAL DEFAULT 72")
        if "reaction_emojis" not in cols:
            c.execute("ALTER TABLE groups ADD COLUMN reaction_emojis TEXT DEFAULT '[\"❤️\"]'")
        if "user_reaction_limit" not in cols:
            c.execute("ALTER TABLE groups ADD COLUMN user_reaction_limit INTEGER DEFAULT 0")
        # Migrate existing account-level reaction settings into each configured group once.
        c.execute("""UPDATE groups SET
            queue_threshold=COALESCE(queue_threshold, CAST(? AS INTEGER)),
            reaction_interval_seconds=COALESCE(reaction_interval_seconds, CAST(? AS REAL)),
            reaction_remove_after_hours=COALESCE(reaction_remove_after_hours, CAST(? AS REAL)),
            reaction_emojis=COALESCE(NULLIF(reaction_emojis,''), ?),
            user_reaction_limit=COALESCE(user_reaction_limit, CAST(? AS INTEGER))""",
            (self.get("queue_threshold","40"), self.get("reaction_interval_seconds","5"),
             self.get("reaction_remove_after_hours","72"), self.get("reaction_emojis",'["❤️"]'),
             self.get("user_reaction_limit","0")))
        # Monitoring is automatic for every configured group; the old per-group
        # Monitor ON/OFF control is no longer used.
        c.execute("UPDATE groups SET monitoring_enabled=1 WHERE valid_group=1")
        c.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_messages_group_message ON messages(group_id, message_id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_messages_created ON messages(created_at)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_pending_group_created ON pending_queue(group_id, created_at)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_reactions_created ON reactions_log(created_at)")
        c.execute("""CREATE TABLE IF NOT EXISTS blocked_users(
            user_id INTEGER PRIMARY KEY, username TEXT DEFAULT '', added_at TEXT)""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_blocked_users_username ON blocked_users(username)")
        self.conn.commit()

    def get(self,k,d=None):
        r=self.conn.execute("SELECT value FROM settings WHERE key=?",(k,)).fetchone()
        return r["value"] if r else d
    def set(self,k,v):
        self.conn.execute("INSERT INTO settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(k,str(v))); self.conn.commit()
    def settings(self):
        def num(k,d,floaty=False):
            try:return float(self.get(k,d)) if floaty else int(self.get(k,d))
            except:return float(d) if floaty else int(d)
        return {"queue_threshold":num("queue_threshold",40),
                "reaction_interval_seconds":num("reaction_interval_seconds",5,True),
                "reaction_remove_after_hours":num("reaction_remove_after_hours",72,True),
                "reaction_send_enabled":self.get("reaction_send_enabled","1") == "1",
                "reaction_emojis":self.reaction_emojis(),
                "user_reaction_limit":num("user_reaction_limit",0),
                "user_reaction_period_hours":num("user_reaction_period_hours",24,True)}

    def reaction_emojis(self):
        raw=self.get("reaction_emojis", self.get("reaction_emoji", "❤️")) or "❤️"
        try:
            vals=json.loads(raw) if raw.strip().startswith("[") else []
        except Exception:
            vals=[]
        if not vals:
            vals=[x.strip() for x in raw.replace("\n",",").replace(";",",").split(",") if x.strip()]
        vals=[str(x) for x in vals if str(x).strip()]
        return vals or ["❤️"]

    def set_reaction_emojis(self, values):
        vals=[str(v).strip() for v in values if str(v).strip()]
        if not vals:
            vals=["❤️"]
        self.set("reaction_emojis", json.dumps(vals, ensure_ascii=False))

    def reaction_interval_seconds(self):
        try:return max(0.0,float(self.get("reaction_interval_seconds","5")))
        except:return 5.0

    def group_last_reaction_at(self,gid):
        r=self.conn.execute("SELECT last_reaction_at FROM groups WHERE group_id=?",(str(gid),)).fetchone()
        try:return float(r[0]) if r and r[0] else None
        except:return None

    def group_reaction_started(self,gid):
        return bool(self.group_last_reaction_at(gid))

    def set_group_last_reaction_at(self,gid,value):
        self.conn.execute("UPDATE groups SET last_reaction_at=? WHERE group_id=?",(float(value),str(gid))); self.conn.commit()

    def add_group(self,gid,username="",title=""):
        self.conn.execute("""INSERT OR IGNORE INTO groups(group_id,group_username,group_title,added_date)
                             VALUES(?,?,?,?)""",
                          (str(gid),username or "",title or "",now()))
        self.conn.commit()
        return True
    def get_group(self,gid):
        r=self.conn.execute("SELECT * FROM groups WHERE group_id=?",(str(gid),)).fetchone()
        return dict(r) if r else None
    def groups(self):
        return [dict(r) for r in self.conn.execute("SELECT * FROM groups WHERE valid_group=1 ORDER BY added_date DESC")]
    def group_settings(self, gid):
        g=self.get_group(gid) or {}
        def num(name, default, floaty=False):
            try: return float(g.get(name, default)) if floaty else int(g.get(name, default))
            except Exception: return float(default) if floaty else int(default)
        raw=g.get("reaction_emojis") or '[\"❤️\"]'
        try: emojis=json.loads(raw) if str(raw).strip().startswith("[") else []
        except Exception: emojis=[]
        if not emojis:
            emojis=[x.strip() for x in str(raw).replace("\n",",").replace(";",",").split(",") if x.strip()]
        return {
            "queue_threshold":max(1,num("queue_threshold",40)),
            "reaction_interval_seconds":max(5.0,num("reaction_interval_seconds",5,True)),
            "reaction_remove_after_hours":max(0.01,num("reaction_remove_after_hours",72,True)),
            "reaction_emojis":[str(x) for x in emojis if str(x).strip()] or ["❤️"],
            "user_reaction_limit":max(0,num("user_reaction_limit",0)),
        }

    def set_group_setting(self,gid,key,value):
        allowed={"queue_threshold","reaction_interval_seconds","reaction_remove_after_hours","reaction_emojis","user_reaction_limit"}
        if key not in allowed: return False
        self.conn.execute(f"UPDATE groups SET {key}=? WHERE group_id=?",(str(value),str(gid))); self.conn.commit(); return True

    def group_reaction_emojis(self,gid): return self.group_settings(gid)["reaction_emojis"]
    def group_reaction_interval_seconds(self,gid): return self.group_settings(gid)["reaction_interval_seconds"]
    def group_user_reaction_limit(self,gid): return self.group_settings(gid)["user_reaction_limit"]

    def update_group(self,gid,**kw):
        allowed={"monitoring_enabled","reaction_enabled","banned","valid_group","group_username","group_title","last_reaction_at","queue_threshold","reaction_interval_seconds","reaction_remove_after_hours","reaction_emojis","user_reaction_limit"}
        f={k:v for k,v in kw.items() if k in allowed}
        if f:
            self.conn.execute("UPDATE groups SET "+",".join(f"{k}=?" for k in f)+" WHERE group_id=?",list(f.values())+[str(gid)])
            self.conn.commit()
    def remove_group(self,gid):
        gid=str(gid)
        for t in ("messages","pending_queue","reactions_log","reaction_removals"): self.conn.execute(f"DELETE FROM {t} WHERE group_id=?",(gid,))
        self.conn.execute("DELETE FROM groups WHERE group_id=?",(gid,)); self.conn.commit()
    def set_monitor_baseline(self,gid,started_at,baseline_msg_id):
        self.conn.execute("UPDATE groups SET monitor_started_at=?, monitor_baseline_msg_id=? WHERE group_id=?",
                          (started_at,int(baseline_msg_id or 0),str(gid))); self.conn.commit()
    def clear_pending_all(self):
        self.conn.execute("DELETE FROM pending_queue"); self.conn.commit()

    def reaction_send_enabled(self):
        return self.get("reaction_send_enabled", "1") == "1"

    def set_reaction_send_enabled(self, enabled):
        self.set("reaction_send_enabled", "1" if enabled else "0")

    def active_reaction_removals(self):
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM reaction_removals WHERE removed=0 ORDER BY id"
        )]

    def current_bd_window_utc(self):
        """Return the current Bangladesh calendar-day window as naive UTC timestamps."""
        tz = ZoneInfo("Asia/Dhaka") if ZoneInfo else timezone(timedelta(hours=6))
        local = datetime.now(tz)
        start_local = datetime.combine(local.date(), datetime.min.time(), tzinfo=tz)
        end_local = start_local + timedelta(days=1)
        start = start_local.astimezone(timezone.utc).replace(tzinfo=None).isoformat(sep=" ", timespec="seconds")
        end = end_local.astimezone(timezone.utc).replace(tzinfo=None).isoformat(sep=" ", timespec="seconds")
        return start, end

    def purge_old_pending(self):
        """Keep only NEW, one-slot-per-user pending work for the current Bangladesh day.

        A pending reaction represents an eligible USER, not every message from
        that user. Once a user has already received today's successful reaction,
        none of their other messages may remain pending. At Bangladesh midnight
        the old queue is discarded, and only a new message can create the next
        day's pending slot.
        """
        start, end = self.current_bd_window_utc()
        removed = 0
        cur = self.conn.execute("DELETE FROM pending_queue WHERE created_at < ?", (start,))
        removed += max(0, cur.rowcount)

        # Remove pending slots for users who already completed today's allowance.
        # This also cleans queues created by older versions of the program.
        cur = self.conn.execute(
            """DELETE FROM pending_queue
               WHERE user_id IS NOT NULL
                 AND EXISTS (
                     SELECT 1 FROM reactions_log r
                      WHERE r.success=1 AND r.user_id=pending_queue.user_id
                        AND r.created_at>=? AND r.created_at<?
                 )""", (start, end))
        removed += max(0, cur.rowcount)

        # Keep only one pending message per user per account DB. The oldest
        # message is the one that can receive today's single reaction.
        cur = self.conn.execute(
            """DELETE FROM pending_queue
               WHERE id NOT IN (
                   SELECT MIN(id) FROM pending_queue
                    WHERE user_id IS NOT NULL
                    GROUP BY user_id
               )
                 AND user_id IS NOT NULL""")
        removed += max(0, cur.rowcount)
        self.conn.commit()
        return removed

    def message_exists(self,gid,msg_id):
        r=self.conn.execute("SELECT 1 FROM messages WHERE group_id=? AND message_id=? LIMIT 1",
                            (str(gid),int(msg_id))).fetchone()
        return bool(r)

    def add_message(self,user_id,username,gid,msg_id,content="",created_at=None):
        # INSERT OR IGNORE is atomic and safe when the live event handler and the
        # periodic history reconciler see the same message at nearly the same time.
        cur=self.conn.execute(
            "INSERT OR IGNORE INTO messages(user_id,username,group_id,message_id,content,created_at) VALUES(?,?,?,?,?,?)",
            (user_id,username or "",str(gid),msg_id,content or "",created_at or now())
        )
        if cur.rowcount == 0:
            return False
        # Daily message count follows the message's actual Telegram date when available.
        day=(created_at or now())[:10]
        self.conn.execute("""INSERT INTO account_activity(day,active,messages,reactions,reacted_users)
                             VALUES(?,1,1,0,0)
                             ON CONFLICT(day) DO UPDATE SET active=1,messages=messages+1""",(day,))
        self.conn.commit()
        return True
    def queue(self,gid):
        return [dict(r) for r in self.conn.execute("SELECT * FROM pending_queue WHERE group_id=? ORDER BY id",(str(gid),))]
    def add_pending(self,gid,chat_id,msg_id,user_id,username,created_at=None):
        # A user gets at most ONE reaction slot per Bangladesh calendar day.
        # Do not queue another message if the user already reacted today or
        # already has another pending message today.
        self.purge_old_pending()
        if user_id is not None and not self.user_can_react(user_id):
            return False
        if user_id is not None:
            existing=self.conn.execute(
                "SELECT 1 FROM pending_queue WHERE user_id=? LIMIT 1", (int(user_id),)
            ).fetchone()
            if existing:
                return False
        cur=self.conn.execute("""INSERT OR IGNORE INTO pending_queue(group_id,chat_id,msg_id,user_id,username,created_at)
                                 VALUES(?,?,?,?,?,?)""",(str(gid),chat_id,msg_id,user_id,username or "",created_at or now()))
        self.conn.commit(); return cur.rowcount>0
    def remove_pending(self,pid):
        self.conn.execute("DELETE FROM pending_queue WHERE id=?",(pid,)); self.conn.commit()
    def remove_pending_for_user(self,uid):
        """Drop other pending messages from a user after their reaction limit is reached.
        The limit is a successful-reaction cap, not a promise to react to every
        message from that user later when the rolling window expires.
        """
        cur=self.conn.execute("DELETE FROM pending_queue WHERE user_id=?",(int(uid),))
        self.conn.commit()
        return cur.rowcount
    def clear_group_queue(self,gid):
        self.conn.execute("DELETE FROM pending_queue WHERE group_id=?",(str(gid),)); self.conn.commit()
    def due_pending(self,gid,cutoff):
        return [dict(r) for r in self.conn.execute("SELECT * FROM pending_queue WHERE group_id=? AND created_at<=? ORDER BY id",(str(gid),cutoff))]
    def pending_count(self,gid):
        return self.conn.execute("SELECT COUNT(*) c FROM pending_queue WHERE group_id=?",(str(gid),)).fetchone()["c"]

    def reaction_trigger_count(self, gid):
        """Count NEW messages received since the current monitoring baseline.

        Queue Threshold is a warm-up count: if it is 40, the first 40 NEW
        messages receive NO reaction. The first reaction may start only when
        message 41 arrives. Every message counts, including multiple messages
        from the same user. The pending queue is still limited to one reaction
        slot per user per Bangladesh day.
        """
        gid = str(gid)
        row = self.conn.execute(
            "SELECT monitor_baseline_msg_id FROM groups WHERE group_id=?",
            (gid,),
        ).fetchone()
        baseline = int(row[0] or 0) if row else 0
        return self.conn.execute(
            """SELECT COUNT(*) c FROM messages m
               WHERE m.group_id=? AND CAST(m.message_id AS INTEGER)>?""",
            (gid, baseline),
        ).fetchone()["c"]

    def pending_count_all(self):
        return self.conn.execute("SELECT COUNT(*) c FROM pending_queue").fetchone()["c"]

    def pending_delete_count(self):
        return self.conn.execute("SELECT COUNT(*) c FROM reaction_removals WHERE removed=0").fetchone()["c"]

    def pending_exists(self,pid):
        return bool(self.conn.execute("SELECT 1 FROM pending_queue WHERE id=?",(int(pid),)).fetchone())

    def oldest_reactable_pending(self,gid):
        """Return the oldest pending message that is at least N messages old.

        Queue Threshold is a rolling message-age rule, not a warm-up flag:
        with threshold=40, the newest 40 messages in a group are ALWAYS
        protected from reaction. A message becomes eligible only after 40
        newer messages have arrived after it. Therefore message #41 is the
        first possible reaction target, message #42 becomes eligible when
        message #42 arrives, etc. This check is done per message so a burst
        cannot cause several of the newest 40 messages to be reacted to.
        """
        self.purge_old_pending()
        try:
            threshold = max(1, int((self.get_group(gid) or {}).get("queue_threshold", 40)))
        except Exception:
            threshold = 40
        gid = str(gid)
        brow = self.conn.execute(
            "SELECT monitor_baseline_msg_id FROM groups WHERE group_id=?", (gid,)
        ).fetchone()
        baseline = int(brow[0] or 0) if brow else 0
        rows=[dict(r) for r in self.conn.execute(
            "SELECT * FROM pending_queue WHERE group_id=? ORDER BY CAST(msg_id AS INTEGER), id",
            (gid,)
        )]
        for row in rows:
            uid = row.get("user_id")
            if uid is not None and self.is_user_blocked(uid):
                continue
            if uid is not None and not self.user_can_react(uid):
                continue
            try:
                msg_id = int(row["msg_id"])
            except Exception:
                continue
            # Count newer messages in THIS monitoring session. A candidate is
            # eligible only when at least `threshold` newer messages exist.
            newer = self.conn.execute(
                """SELECT COUNT(*) c FROM messages
                   WHERE group_id=? AND CAST(message_id AS INTEGER)>?
                     AND CAST(message_id AS INTEGER)>?""",
                (gid, msg_id, baseline),
            ).fetchone()["c"]
            if int(newer) >= threshold:
                return row
        return None

    def block_user(self, uid, username=""):
        self.conn.execute("INSERT INTO blocked_users(user_id,username,added_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET username=excluded.username",
                          (int(uid), username or "", now())); self.conn.commit()

    def unblock_user(self, uid):
        self.conn.execute("DELETE FROM blocked_users WHERE user_id=?", (int(uid),)); self.conn.commit()

    def is_user_blocked(self, uid):
        return bool(self.conn.execute("SELECT 1 FROM blocked_users WHERE user_id=?", (int(uid),)).fetchone())

    def blocked_users(self):
        return [dict(r) for r in self.conn.execute("SELECT * FROM blocked_users ORDER BY added_at DESC")]

    def user_reaction_limit(self, gid=None):
        source=(self.get_group(gid) or {}).get("user_reaction_limit","0") if gid is not None else self.get("user_reaction_limit","0")
        try: limit=int(float(source))
        except: limit=0
        try: hours=float(self.get("user_reaction_period_hours","24"))
        except: hours=24
        return max(0,limit), max(0.01,hours)

    def user_reaction_count(self,uid,hours=None):
        """Count successful reactions for the user's CURRENT Bangladesh calendar day.

        The old rolling-hours behavior is intentionally no longer used: after
        Bangladesh midnight the user's allowance starts fresh.
        """
        start, end = self.current_bd_window_utc()
        return self.conn.execute(
            "SELECT COUNT(*) c FROM reactions_log WHERE success=1 AND user_id=? AND created_at>=? AND created_at<?",
            (uid,start,end)).fetchone()["c"]

    def user_can_react(self,uid,gid=None):
        limit,_ = self.user_reaction_limit(gid)
        return True if limit <= 0 else self.user_reaction_count(uid) < limit

    def log_reaction(self,gid,uid,msgid,emoji,success=True,error=None):
        self.conn.execute("""INSERT INTO reactions_log(group_id,user_id,message_id,emoji,success,error,created_at)
                             VALUES(?,?,?,?,?,?,?)""",(str(gid),uid,msgid,emoji,1 if success else 0,error,now()))
        if success:
            d=today()
            self.conn.execute("""INSERT INTO account_activity(day,active,messages,reactions,reacted_users)
                                 VALUES(?,0,0,1,1)
                                 ON CONFLICT(day) DO UPDATE SET reactions=reactions+1,reacted_users=reacted_users+1""",(d,))
        self.conn.commit()
    def add_removal(self,gid,chat_id,msgid,uid,emoji):
        try:h=float((self.get_group(gid) or {}).get("reaction_remove_after_hours",72))
        except:h=72
        when=(datetime.utcnow()+timedelta(hours=h)).isoformat(sep=" ",timespec="seconds")
        created = now()
        self.conn.execute("""INSERT INTO reaction_removals(
                             group_id,chat_id,msg_id,user_id,emoji,remove_after,created_at)
                             VALUES(?,?,?,?,?,?,?)""",
                          (str(gid),chat_id,msgid,uid,emoji,when,created))
        self.conn.commit()
    def expired_removals(self):
        return [dict(r) for r in self.conn.execute("SELECT * FROM reaction_removals WHERE removed=0 AND remove_after<=? ORDER BY id",(now(),))]
    def mark_removed(self,rid):
        self.conn.execute("UPDATE reaction_removals SET removed=1,removed_at=? WHERE id=?",(now(),rid)); self.conn.commit()

    def reschedule_active_removals(self, gid, hours):
        """Apply a newly selected delete delay to reactions that are still pending.

        This makes changing a group's Delete Time useful immediately: if an admin
        changes 72h to 0.2h while a reaction is already waiting for deletion, the
        existing pending reaction is moved to the new deadline instead of keeping
        the old 72h deadline.
        """
        try:
            h = max(0.01, float(hours))
        except Exception:
            return 0
        rows = self.conn.execute(
            "SELECT id,created_at FROM reaction_removals WHERE group_id=? AND removed=0",
            (str(gid),)
        ).fetchall()
        changed = 0
        for r in rows:
            created = r["created_at"] or now()
            try:
                base = datetime.strptime(created, "%Y-%m-%d %H:%M:%S")
                when = (base + timedelta(hours=h)).isoformat(sep=" ", timespec="seconds")
            except Exception:
                when = (datetime.utcnow() + timedelta(hours=h)).isoformat(sep=" ", timespec="seconds")
            self.conn.execute("UPDATE reaction_removals SET remove_after=? WHERE id=?", (when, r["id"]))
            changed += 1
        self.conn.commit()
        return changed

    def stats(self):
        total=self.conn.execute("SELECT COUNT(*) c FROM reactions_log WHERE success=1").fetchone()["c"]
        reacted_users=self.conn.execute("SELECT COUNT(DISTINCT user_id) c FROM reactions_log WHERE success=1").fetchone()["c"]
        msgs=self.conn.execute("SELECT COUNT(*) c FROM messages").fetchone()["c"]
        monitored_users=self.conn.execute("SELECT COUNT(DISTINCT user_id) c FROM messages WHERE user_id IS NOT NULL").fetchone()["c"]
        groups=self.conn.execute("SELECT COUNT(*) c FROM groups WHERE valid_group=1").fetchone()["c"]
        return {"lifetime_reactions":total,"lifetime_users":reacted_users,
                "lifetime_monitored_users":monitored_users,"lifetime_messages":msgs,"groups":groups,
                "pending":self.conn.execute("SELECT COUNT(*) c FROM pending_queue").fetchone()["c"],
                "pending_deletes":self.conn.execute("SELECT COUNT(*) c FROM reaction_removals WHERE removed=0").fetchone()["c"]}
    def reset_daily_stats(self, reset_at=None):
        self.set("daily_reset_at", reset_at or now())
        self.clear_pending_all()

    def daily(self, day=None):
        tz = ZoneInfo("Asia/Dhaka") if ZoneInfo else timezone(timedelta(hours=6))
        local_now = datetime.now(tz)
        if day is None:
            target = local_now.date()
        elif hasattr(day, "year"):
            target = day
        else:
            target = datetime.strptime(str(day), "%Y-%m-%d").date()
        start_local = datetime.combine(target, datetime.min.time(), tzinfo=tz)
        end_local = start_local + timedelta(days=1)
        start = start_local.astimezone(timezone.utc).replace(tzinfo=None).isoformat(sep=" ",timespec="seconds")
        end = end_local.astimezone(timezone.utc).replace(tzinfo=None).isoformat(sep=" ",timespec="seconds")
        reset_at = self.get("daily_reset_at", "")
        if reset_at and target == local_now.date():
            start = max(start, reset_at)
        messages=self.conn.execute("SELECT COUNT(*) c FROM messages WHERE created_at>=? AND created_at<?",(start,end)).fetchone()["c"]
        reactions=self.conn.execute("SELECT COUNT(*) c FROM reactions_log WHERE success=1 AND created_at>=? AND created_at<?",(start,end)).fetchone()["c"]
        reacted_users=self.conn.execute("SELECT COUNT(DISTINCT user_id) c FROM reactions_log WHERE success=1 AND created_at>=? AND created_at<?",(start,end)).fetchone()["c"]
        monitored_users=self.conn.execute("SELECT COUNT(DISTINCT user_id) c FROM messages WHERE created_at>=? AND created_at<? AND user_id IS NOT NULL",(start,end)).fetchone()["c"]
        deletes=self.conn.execute("SELECT COUNT(*) c FROM reaction_removals WHERE removed=1 AND removed_at>=? AND removed_at<?",(start,end)).fetchone()["c"]
        return {"active":True,"messages":messages,"reactions":reactions,"reacted_users":reacted_users,"monitored_users":monitored_users,"deletes":deletes,"day":target.strftime("%Y-%m-%d")}

    def daily_group_status(self, day=None):
        tz = ZoneInfo("Asia/Dhaka") if ZoneInfo else timezone(timedelta(hours=6))
        local_now = datetime.now(tz)
        target = local_now.date() if day is None else (day if hasattr(day,"year") else datetime.strptime(str(day), "%Y-%m-%d").date())
        start_local = datetime.combine(target, datetime.min.time(), tzinfo=tz)
        end_local = start_local + timedelta(days=1)
        start = start_local.astimezone(timezone.utc).replace(tzinfo=None).isoformat(sep=" ",timespec="seconds")
        end = end_local.astimezone(timezone.utc).replace(tzinfo=None).isoformat(sep=" ",timespec="seconds")
        rows = []
        for g in self.groups():
            gid = str(g["group_id"])
            sent = self.conn.execute(
                "SELECT COUNT(*) c FROM reactions_log WHERE success=1 AND group_id=? AND created_at>=? AND created_at<?",
                (gid,start,end)).fetchone()["c"]
            pending = self.conn.execute(
                "SELECT COUNT(*) c FROM pending_queue WHERE group_id=? AND created_at>=? AND created_at<?",
                (gid,start,end)).fetchone()["c"]
            messages = self.conn.execute(
                "SELECT COUNT(*) c FROM messages WHERE group_id=? AND created_at>=? AND created_at<?",
                (gid,start,end)).fetchone()["c"]
            rows.append({"group_id":gid, "group_username":g.get("group_username") or "",
                         "group_title":g.get("group_title") or "", "messages":messages,
                         "reactions":sent, "pending":pending})
        return rows

    def daily_reaction_breakdown(self, day=None):
        tz = ZoneInfo("Asia/Dhaka") if ZoneInfo else timezone(timedelta(hours=6))
        local_now = datetime.now(tz)
        target = local_now.date() if day is None else (day if hasattr(day,"year") else datetime.strptime(str(day), "%Y-%m-%d").date())
        start_local=datetime.combine(target,datetime.min.time(),tzinfo=tz); end_local=start_local+timedelta(days=1)
        start=start_local.astimezone(timezone.utc).replace(tzinfo=None).isoformat(sep=" ",timespec="seconds")
        end=end_local.astimezone(timezone.utc).replace(tzinfo=None).isoformat(sep=" ",timespec="seconds")
        return [dict(r) for r in self.conn.execute(
            "SELECT group_id, COUNT(*) AS reactions FROM reactions_log WHERE success=1 AND created_at>=? AND created_at<? GROUP BY group_id ORDER BY reactions DESC",(start,end))]

    def block_user(self, uid, username=""):
        self.conn.execute("INSERT INTO blocked_users(user_id,username,added_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET username=excluded.username",
                          (int(uid), username or "", now()))
        self.conn.commit()

    def unblock_user(self, uid):
        self.conn.execute("DELETE FROM blocked_users WHERE user_id=?", (int(uid),)); self.conn.commit()

    def is_user_blocked(self, uid):
        return bool(self.conn.execute("SELECT 1 FROM blocked_users WHERE user_id=?", (int(uid),)).fetchone())

    def blocked_users(self):
        return [dict(r) for r in self.conn.execute("SELECT * FROM blocked_users ORDER BY added_at DESC")]

    def close(self): self.conn.close()

class MasterDatabase:
    """Small control DB; each account's operational data lives in its own DB."""
    def __init__(self,path=None):
        # Always resolve the control DB relative to the application files, not
        # the shell/service working directory. This prevents accounts appearing
        # to disappear when the bot is started from a different directory.
        if path is None:
            path = os.path.join(BASE_DIR, "data", "accounts.sqlite")
        elif not os.path.isabs(path):
            path = os.path.join(BASE_DIR, path)
        os.makedirs(os.path.dirname(path) or ".",exist_ok=True)
        self.conn=sqlite3.connect(path,check_same_thread=False); self.conn.row_factory=sqlite3.Row
        self.conn.execute("CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT)")
        self.conn.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('bot_enabled','0')")
        self.conn.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('auto_cycle_enabled','0')")
        self.conn.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('auto_cycle_minutes','20')")
        self.conn.execute("""CREATE TABLE IF NOT EXISTS accounts(
            id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT UNIQUE, session_file TEXT,
            status TEXT DEFAULT 'active', added_at TEXT, last_error TEXT DEFAULT '')""")
        self.conn.execute("""CREATE TABLE IF NOT EXISTS blocked_users(
            user_id INTEGER PRIMARY KEY, username TEXT DEFAULT '', added_at TEXT)""")
        self.conn.execute("CREATE INDEX IF NOT EXISTS idx_master_blocked_username ON blocked_users(username)")
        self.conn.commit()
    def add_account(self,phone,session_file):
        self.conn.execute("INSERT OR IGNORE INTO accounts(phone,session_file,added_at) VALUES(?,?,?)",(phone,session_file,now())); self.conn.commit()
        return self.get_by_phone(phone)
    def accounts(self): return [dict(r) for r in self.conn.execute("SELECT * FROM accounts ORDER BY id")]
    def get(self,aid):
        r=self.conn.execute("SELECT * FROM accounts WHERE id=?",(int(aid),)).fetchone(); return dict(r) if r else None
    def get_by_phone(self,p):
        r=self.conn.execute("SELECT * FROM accounts WHERE phone=?",(p,)).fetchone(); return dict(r) if r else None
    def set_session_file(self,aid,path):
        self.conn.execute("UPDATE accounts SET session_file=? WHERE id=?",(path,int(aid))); self.conn.commit()
    def set_status(self,aid,status,error=""):
        self.conn.execute("UPDATE accounts SET status=?,last_error=? WHERE id=?",(status,error,int(aid))); self.conn.commit()
    def remove(self,aid): self.conn.execute("DELETE FROM accounts WHERE id=?",(int(aid),)); self.conn.commit()
    def get_setting(self,key,default=None):
        r=self.conn.execute("SELECT value FROM settings WHERE key=?",(key,)).fetchone()
        return r["value"] if r else default
    def set_setting(self,key,value):
        self.conn.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(key,str(value))); self.conn.commit()
    def block_user(self, uid, username=""):
        self.conn.execute("INSERT INTO blocked_users(user_id,username,added_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET username=excluded.username",
                          (int(uid), username or "", now()))
        self.conn.commit()
    def unblock_user(self, uid):
        self.conn.execute("DELETE FROM blocked_users WHERE user_id=?", (int(uid),)); self.conn.commit()
    def is_user_blocked(self, uid):
        return bool(self.conn.execute("SELECT 1 FROM blocked_users WHERE user_id=?", (int(uid),)).fetchone())
    def blocked_users(self):
        return [dict(r) for r in self.conn.execute("SELECT * FROM blocked_users ORDER BY added_at DESC")]
    def close(self): self.conn.close()
