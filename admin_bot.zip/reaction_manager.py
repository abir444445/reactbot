import asyncio
import logging
import time

logger = logging.getLogger(__name__)


class ReactionManager:
    """Queue-based reaction scheduler.

    Queue Threshold is the only queue trigger. There is deliberately no Reaction
    Time setting. The threshold is a NEW-message warm-up: if the threshold is 40,
    the first 40 new messages are never reacted to; reaction starts from message
    41. After that, the oldest eligible pending user/message is reacted to.
    When a user reaches the limit, their other pending messages are skipped rather
    than being held until the rolling window expires.

    Reaction Interval is a per-group delay in seconds between successful reaction
    sends. It does not delay message monitoring or other groups.
    """

    def __init__(self, db, send_callback, global_block_checker=None):
        self.db = db
        self.send_callback = send_callback
        self.remove_callback = None
        self.global_block_checker = global_block_checker or (lambda uid: False)
        self.running = False
        self.tasks = []
        self.locks = {}
        self.reaction_queue = asyncio.Queue(maxsize=20000)
        self.queued_ids = set()
        self.flood_until = 0.0
        self._flood_notice_at = 0.0
        self._seq = 0
        self.watchdog_task = None

    def lock(self, gid):
        if gid not in self.locks:
            self.locks[gid] = asyncio.Lock()
        return self.locks[gid]

    def set_floodwait(self, seconds):
        seconds = max(1, int(seconds))
        self.flood_until = max(self.flood_until, time.monotonic() + seconds)
        return self.flood_until

    def flood_active(self):
        return time.monotonic() < self.flood_until

    async def start(self):
        if self.running:
            return
        self.running = True
        self.tasks = [
            asyncio.create_task(self.reaction_worker(), name="reaction-worker-1"),
            asyncio.create_task(self.reaction_worker(), name="reaction-worker-2"),
            asyncio.create_task(self.reaction_worker(), name="reaction-worker-3"),
            asyncio.create_task(self.reaction_worker(), name="reaction-worker-4"),
            asyncio.create_task(self.reaction_worker(), name="reaction-worker-5"),
            asyncio.create_task(self.reaction_worker(), name="reaction-worker-6"),
            asyncio.create_task(self.reaction_worker(), name="reaction-worker-7"),
            asyncio.create_task(self.reaction_worker(), name="reaction-worker-8"),
            asyncio.create_task(self.limit_retry_loop(), name="reaction-limit-retry-loop"),
            asyncio.create_task(self.remove_loop(), name="reaction-remove-loop"),
        ]
        self.watchdog_task = asyncio.create_task(self._watchdog_loop(), name="reaction-watchdog")
        self.tasks.append(self.watchdog_task)
        # If Bot ON happens after a restart and the queue already contains enough
        # work, resume from the threshold without backfilling old messages.
        if self.db.reaction_send_enabled():
            for g in self.db.groups():
                if g["monitoring_enabled"] and g["reaction_enabled"]:
                    self._schedule_threshold(g)

    async def stop(self):
        self.running = False
        for t in self.tasks:
            if not t.done():
                t.cancel()
        for t in self.tasks:
            try:
                await t
            except asyncio.CancelledError:
                pass
        self.tasks = []
        self.watchdog_task = None
        self.queued_ids.clear()
        while not self.reaction_queue.empty():
            try:
                self.reaction_queue.get_nowait()
            except asyncio.QueueEmpty:
                break

    def _spawn_missing_tasks(self):
        """Recreate unexpectedly terminated scheduler tasks without resetting queues."""
        if not self.running:
            return
        names = {t.get_name(): t for t in self.tasks if not t.done()}
        wanted_workers = [f"reaction-worker-{i}" for i in range(1, 9)]
        for name in wanted_workers:
            if name not in names:
                t = asyncio.create_task(self.reaction_worker(), name=name)
                self.tasks.append(t)
                logger.warning("restarted dead reaction task: %s", name)
        for name, coro in (("reaction-limit-retry-loop", self.limit_retry_loop), ("reaction-remove-loop", self.remove_loop)):
            if name not in names:
                t = asyncio.create_task(coro(), name=name)
                self.tasks.append(t)
                logger.warning("restarted dead reaction task: %s", name)

    async def _watchdog_loop(self):
        """Keep reaction workers/schedulers alive after unexpected task failures."""
        while self.running:
            try:
                self._spawn_missing_tasks()
                # Reconcile eligible pending work even if a scheduler task was
                # temporarily unavailable. This never creates duplicate slots.
                if not self.flood_active() and self.db.reaction_send_enabled():
                    for g in self.db.groups():
                        if g["monitoring_enabled"] and g["reaction_enabled"]:
                            self._schedule_threshold(g)
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("reaction watchdog failed")
            await asyncio.sleep(10)

    async def new_message(self, gid, chat_id, msg_id, uid, username, created_at=None):
        g = self.db.get_group(gid)
        if not g or not g["monitoring_enabled"] or not g["reaction_enabled"] or not self.db.reaction_send_enabled():
            return
        # A pending reaction is valid only for the Bangladesh calendar day in
        # which the message was received. Never carry yesterday's queue forward.
        self.db.purge_old_pending()
        inserted = self.db.add_pending(gid, chat_id, msg_id, uid, username, created_at=created_at)
        if not inserted:
            return
        self._schedule_threshold(g)

    def _schedule_threshold(self, g):
        if not self.running or not self.db.reaction_send_enabled() or not g.get("monitoring_enabled") or not g.get("reaction_enabled"):
            return False
        # Queue Threshold is a rolling message-age rule, not a one-time
        # warm-up. The newest N messages are ALWAYS protected. A candidate
        # becomes eligible only after N newer messages exist in this group.
        self.db.purge_old_pending()
        row = self.db.oldest_reactable_pending(g["group_id"])
        return self.enqueue(row, g) if row else False

    def enqueue(self, row, g):
        if not row or not self.running:
            return False
        rid = int(row["id"])
        if rid in self.queued_ids:
            return False
        try:
            self.reaction_queue.put_nowait((row, g))
            self.queued_ids.add(rid)
            return True
        except asyncio.QueueFull:
            logger.warning("reaction queue full; keeping pending row %s", rid)
            return False

    async def reaction_worker(self):
        while self.running:
            try:
                row, g = await self.reaction_queue.get()
                rid = int(row["id"])
                self.queued_ids.discard(rid)
                try:
                    await self.react(row, g)
                finally:
                    self.reaction_queue.task_done()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("reaction worker failed")

    async def react(self, row, g):
        gid = g["group_id"]
        async with self.lock(gid):
            # The row may have been removed by another worker/restart.
            if not self.db.pending_exists(row["id"]):
                return
            if self.global_block_checker(int(row["user_id"])):
                self.db.remove_pending(row["id"])
                self._schedule_threshold(g)
                return
            if not self.db.user_can_react(row["user_id"], gid):
                # This user's limit is full. Try another user in the same queue.
                self._schedule_threshold(g)
                return

            # Telegram FloodWait is authoritative. It pauses only this reaction
            # attempt; message ingestion continues and pending rows stay intact.
            if self.flood_active():
                delay = max(0.05, self.flood_until - time.monotonic())
                await asyncio.sleep(delay)

            # Per-group reaction interval. Holding only this group's lock means
            # another group can react independently while this one waits.
            interval = self.db.group_reaction_interval_seconds(gid)
            last = self.db.group_last_reaction_at(gid)
            if last is not None:
                delay = interval - (time.time() - last)
                if delay > 0:
                    await asyncio.sleep(delay)

            if not self.db.pending_exists(row["id"]):
                return
            if self.global_block_checker(int(row["user_id"])):
                self.db.remove_pending(row["id"])
                self._schedule_threshold(g)
                return
            if not self.db.user_can_react(row["user_id"], gid):
                self._schedule_threshold(g)
                return

            ok = await self.send_callback(row, g)
            if ok:
                self.db.remove_pending(row["id"])
                self.db.set_group_last_reaction_at(gid, time.time())
                # Once this user has reached the configured daily limit, do not
                # keep all of their other messages in Pending. Those messages are
                # intentionally skipped; a later message can become eligible only
                # after the Bangladesh calendar day resets and the user sends a new message.
                limit, _ = self.db.user_reaction_limit(gid)
                if limit > 0 and not self.db.user_can_react(row["user_id"], gid):
                    self.db.remove_pending_for_user(row["user_id"])
                # Continue with the next eligible user/message.
                self._schedule_threshold(g)

    async def limit_retry_loop(self):
        # Reaction allowance resets at Bangladesh midnight. Pending messages from
        # the previous day are discarded; only a NEW message on the new day can
        # receive that day's reaction.
        while self.running:
            try:
                self.db.purge_old_pending()
                if self.db.reaction_send_enabled():
                    for g in self.db.groups():
                        if g["monitoring_enabled"] and g["reaction_enabled"]:
                            self._schedule_threshold(g)
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("reaction limit retry loop failed")
            await asyncio.sleep(5)

    async def remove_loop(self):
        # FIXED: per-row exception guard + success logging. A single failing
        # removal can no longer disrupt the loop, and every successful removal
        # is written to the log so it can be verified in bot.log.
        while self.running:
            try:
                if self.flood_active():
                    await asyncio.sleep(min(2, max(0.05, self.flood_until - time.monotonic())))
                    continue
                due = self.db.expired_removals()[:100]
                for r in due:
                    if not self.remove_callback:
                        break
                    try:
                        ok = await self.remove_callback(r)
                    except asyncio.CancelledError:
                        raise
                    except Exception:
                        logger.exception("reaction removal error (row %s)", r.get("id"))
                        ok = False
                    if ok:
                        self.db.mark_removed(r["id"])
                        logger.info("reaction removal done: row %s group %s msg %s",
                                    r["id"], r["group_id"], r["msg_id"])
                    if self.flood_active():
                        break
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("reaction removal loop failed")
            # Keep the scheduler responsive so short test values such as
            # 0.2 hours (12 minutes) are handled within about one second.
            await asyncio.sleep(1)